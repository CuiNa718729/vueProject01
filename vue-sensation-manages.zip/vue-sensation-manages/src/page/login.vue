<template>
  <div class="login_bac fillcontain">
    <transition name="formed" mode="in-out">
      <section class="form_inner" v-show="showLogin">
        <div class="form_title">
          <span>中科深度舆情监测系统</span>
        </div>
        <el-form :model="formInfo" ref="formInfo" :rules="rules">
          <el-form-item prop="userName">
            <el-input placeholder="用户名" v-model.trim="formInfo.userName"></el-input>
          </el-form-item>
          <el-form-item prop="password">
            <el-input type="password" placeholder="密码" v-model="formInfo.password"
                      @keyup.enter.native="submitForm('formInfo')"></el-input>
          </el-form-item>
          <el-form-item>
            <el-checkbox v-model="checked" class="remember_password">记住密码</el-checkbox>
            <span class="forget_password">忘记密码?</span>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" class="submit_btn" @click="submitForm('formInfo')">登录</el-button>
            <el-button class="submit_btn" @click="resetForm('formInfo')">重置</el-button>
          </el-form-item>
        </el-form>
      </section>
    </transition>
  </div>
</template>

<script>
  import api from '../api/api'
  import {mapActions} from 'vuex'

  export default {
    name: "login",
    data() {
      return {
        formInfo: {
          userName: '',
          password: '',
        },
        showLogin: false,
        rules: {
          userName: [
            {required: true, message: '请输入用户名', trigger: 'blur'},
          ],
          password: [
            {required: true, message: '请输入密码', trigger: 'blur'}
          ],
        },
        checked: true
      };
    },
    mounted() {
      this.showLogin = true;
      this.getCookie()
    },
    methods: {
      ...mapActions(['setUserInfo', 'getKeywords']),
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            api.Login({customerName: this.formInfo.userName, password: this.formInfo.password})
              .then(res => {
                if (res.status == 200) {
                  if (this.checked) {
                    // console.log('保存cookie');
                    this.setCookie(this.formInfo.userName, this.formInfo.password, 7)
                  } else {
                    // console.log('清除cookie');
                    this.removeCookie()
                  }
                  this.$message({
                    type: 'success',
                    message: '登录成功!'
                  });
                  let data = {
                    userName: this.formInfo.userName
                  };
                  this.setUserInfo(data);
                  this.getKeywords();
                  this.$router.push('/manage')
                } else {
                  this.$message({
                    type: 'error',
                    message: res.message
                  });
                }
              }).catch(e => {
              console.log(e);
            });
          } else {
            this.$notify.error({
              title: '错误',
              message: '请输入正确的用户名密码'
            });
            return false;
          }
        })
      },
      resetForm(formName) {
        this.$refs[formName].resetFields();
      },
      setCookie(name, pwd, range) {
        const date = new Date();
        date.setTime(date.getTime() + 24 * 60 * 60 * 1000 * range);
        window.document.cookie = `userName=${name};path=/;expires=${date.toGMTString()}`;
        window.document.cookie = `password=${pwd};path=/;expires=${date.toGMTString()}`
      },
      getCookie() {
        if (document.cookie.length > 0) {
          let info = document.cookie.split('; ');
          for (let i = 0; i < info.length; i++) {
            let info2 = info[i].split('=');
            //判断查找相对应的值
            if (info2[0] == 'userName') {
              this.formInfo.userName = info2[1];
            } else if (info2[0] == 'password') {
              this.formInfo.password = info2[1];
            }
          }
        }
      },
      removeCookie() {
        this.setCookie("", "", -1);
      }
    }
  }
</script>

<style scoped lang="less">
  @import "../style/mixin.less";

  .login_bac {
    position: relative;
    background: url("../assets/login.png") no-repeat center;
    background-size: cover;
    .form_inner {
      width: 390px;
      height: 220px;
      .ctp(400px, 300px);
      background-color: #fff;
      border-radius: 5px;
      padding: 25px;
      text-align: center;
      .form_title {
        position: absolute;
        width: 100%;
        top: -100px;
        left: 0;
        span {
          font-size: 34px;
          color: #fff;
        }
      }
      .submit_btn {
        font-size: 16px;
        padding: 12px 75px;
      }
      .remember_password {
        float: left;
      }
      .forget_password {
        display: inline-block;
        float: right;
        cursor: pointer;
      }
    }
  }

  .formed-enter-active, .formed-leave-active {
    transition: all 1s;
  }

  .formed-enter, .formed-leave-active {
    transform: translate3d(0, -50px, 0);
    opacity: 0;
  }

</style>
