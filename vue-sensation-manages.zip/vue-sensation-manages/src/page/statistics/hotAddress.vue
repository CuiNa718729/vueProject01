<template>
  <div class="main-content">
    <div class="main-inner">
      <div class="main-detail">
        <div class="m-d-select">
          <span>用户关键词：</span>
          <el-select v-model="keyword" filterable placeholder="默认全部">
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
          <span class="d-select-date">日期范围：</span>
          <el-date-picker
            v-model="timeAround"
            type="daterange"
            align="right"
            unlink-panels
            value-format="yyyy-MM-dd"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            :picker-options="pickerOptions2"
            :default-value="timeDefaultShow">
          </el-date-picker>
          <el-button type="primary" icon="el-icon-search" @click="searchInfo">搜索</el-button>
        </div>
        <address-echarts :keyword="keyword" :timeRange="timeRange"></address-echarts>
      </div>
    </div>
  </div>
</template>

<script>
  import addressEcharts from '../../components/addressEcharts'
  import {mapState} from 'vuex'

  export default {
    name: "hot-address",
    data() {
      return {
        keyword: '',
        pickerOptions2: {
          disabledDate(time) {
            return time.getTime() > Date.now();
          },
          shortcuts: [{
            text: '最近一周',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
              picker.$emit('pick', [start, end]);
            }
          }, {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
              picker.$emit('pick', [start, end]);
            }
          }, {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
              picker.$emit('pick', [start, end]);
            }
          }]
        },
        timeRange: '',
        timeAround: '',
        timeDefaultShow: ''
      }
    },
    mounted() {
      this.timeDefaultShow = new Date();
      this.timeDefaultShow.setMonth(new Date().getMonth() - 1);
    },
    computed: {
      ...mapState(['options']),
    },
    components: {
      addressEcharts
    },
    methods: {
      searchInfo() {
        this.timeRange = this.timeAround
      }
    }
  }
</script>

<style scoped lang="less">
  @import "../../style/mixin.less";
</style>
