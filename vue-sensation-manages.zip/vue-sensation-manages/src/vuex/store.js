import Vue from 'vue'
import Vuex from 'vuex'
import api from '../api/api'

Vue.use(Vuex)

const state = {
  userInfo: JSON.parse(localStorage.getItem('userInfo')) || {},
  options: JSON.parse(localStorage.getItem('options')) || {},
};

const mutations = {
  saveUserInfo(state, userInfo){
    state.userInfo = userInfo
  },
  saveKeyword(state, options){
    state.options = options
  }
};

const actions = {
  setUserInfo({ commit },res){
    localStorage.setItem('userInfo', JSON.stringify(res));
    commit('saveUserInfo',res)
  },
  getKeywords({ commit }){
    api.GetKeyword().then(res => {
      let options = [];
      for(let i=0; i<res.length; i++){
        options.push({
          value:res[i],
          label:res[i]
        })
      }
      localStorage.setItem('options', JSON.stringify(options));
      commit('saveKeyword',options)
    })
  }
};

export default new Vuex.Store({
  state,
  actions,
  mutations,
})
