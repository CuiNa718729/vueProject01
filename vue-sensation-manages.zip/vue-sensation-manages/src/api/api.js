import axios from 'axios'
import qs from 'qs'

// axios 配置
axios.defaults.timeout = 1000000;
axios.defaults.withCredentials = true;
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=UTF-8';
axios.defaults.baseURL = 'http://192.168.1.179:8080/peacock/';

//POST传参序列化
axios.interceptors.request.use((config) => {
  if(config.method  === 'post'){
    config.data = qs.stringify(config.data,{arrayFormat: 'brackets'});
  }
  return config;
},(error) =>{
  // _.toast("错误的传参", 'fail');
  return Promise.reject(error);
});

//返回状态判断
axios.interceptors.response.use((res) =>{
  return res;
}, (error) => {
  // _.toast("网络异常", 'fail');
  return Promise.reject(error);
});

export function fetch(url, params) {
  return new Promise((resolve, reject) => {
    axios.post(url, params)
      .then(response => {
        resolve(response.data);
      }, err => {
        reject(err);
      })
      .catch((error) => {
        reject(error)
      })
  })
}

export default {
  /**
   * 用户登录
   */
  Login(params) {
    return fetch('/customerLogin/customerLogon', params)
  },

  /**
   * 获取下拉选择项
   */
  GetKeyword() {
    return fetch('/dataStatistic/getUserKeywords')
  },

  /**
   * 获取（全国）地图数据
   */
  HotMap(params) {
    return fetch('/dataStatistic/hotMapJSON', params)
  },

  /**
   * 获取（省份）地图数据
   */
  HotProvinceMap(params) {
    return fetch('/dataStatistic/hotMapProvinceJSON', params)
  },

  /**
   * 获取热点机构数据
   */
  HotOrganization(params) {
    return fetch('/dataStatistic/hotOrganizationJSON', params)
  },

  /**
   * 获取热点人物数据
   */
  HotPeople(params) {
    return fetch('/dataStatistic/hotPeopleJSON', params)
  },

  /**
   * 获取热点来源数据
   */
  HotResource(params) {
    return fetch('/dataStatistic/hotPlatformJSON', params)
  },

  /**
   * 获取活跃媒体数据
   */
  HotSource(params) {
    return fetch('/dataStatistic/hotMediaJSON', params)
  },

  /**
   * 获取正负倾向数据
   */
  Polarity(params) {
    return fetch('/dataStatistic/polarityPercentageJSON', params)
  },

  /**
   * 获取预测数据
   */
  Trend(params) {
    return fetch('/dataStatistic/trendJSON', params)
  },

  /**
   * 获取人物关系
   */
  Relationship(params) {
    return fetch('/dataStatistic/relationShipJSON', params)
  },

  /**
   * 搜索结果
   */
  Search(params) {
    return fetch('/searchInterface/search', params)
  },

  /**
   * 搜索筛选结果
   */
  SearchDetail(params) {
    return fetch('/searchInterface/searchDetail', params)
  },
}
