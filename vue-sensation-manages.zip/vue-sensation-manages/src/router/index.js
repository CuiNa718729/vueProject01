import Vue from 'vue'
import Router from 'vue-router'

const login = r => require.ensure([], () => r(require('@/page/login')), 'login');
const headerTop = r => require.ensure([], () => r(require('@/page/headerTop')), 'headerTop');
const home = r => require.ensure([], () => r(require('@/page/home')), 'home');
const hotAddress = r => require.ensure([], () => r(require('@/page/statistics/hotAddress')), 'hotAddress');
const hotPeople = r => require.ensure([], () => r(require('@/page/statistics/hotPeople')), 'hotPeople');
const hotAgency = r => require.ensure([], () => r(require('@/page/statistics/hotAgency')), 'hotAgency');
const hotSource = r => require.ensure([], () => r(require('@/page/statistics/hotSource')), 'hotSource');
const hotResource = r => require.ensure([], () => r(require('@/page/statistics/hotResource')), 'hotResource');
const keywordTrend = r => require.ensure([], () => r(require('@/page/statistics/keywordTrend')), 'keywordTrend');
const peopleRelationship = r => require.ensure([], () => r(require('@/page/statistics/peopleRelationship')), 'peopleRelationship');
const forecast = r => require.ensure([], () => r(require('@/page/statistics/forecast')), 'forecast');
const searchDetail = r => require.ensure([], () => r(require('@/page/searchDetail')), 'searchDetail');
const warningList = r => require.ensure([], () => r(require('@/page/monitor/warningList')), 'warningList');
const warningCharts = r => require.ensure([], () => r(require('@/page/monitor/warningCharts')), 'warningCharts');
const NotFoundView = r => require.ensure([], () => r(require('@/components/notFound')), 'NotFoundView');

Vue.use(Router)

export default new Router({
  mode: 'history',
  base: '/peacock/zhk/',
  routes: [
    {
      path: '/',
      component: login
    },
    {
      path: '*',
      component: NotFoundView
    },
    {
      path: '/manage',
      component: headerTop,
      children: [
        {
          path: '',
          component: home,
          meta: []
        },
        {
          path: '/searchResult',
          component: searchDetail,
          meta: ['搜索详情']
        },
        {
          path: '/warningList',
          component: warningList,
          meta: ['舆情监测', '信息列表']
        },
        {
          path: '/warningCharts',
          component: warningCharts,
          meta: ['舆情监测', '图表统计']
        },
        {
          path: '/hotAddress',
          component: hotAddress,
          meta: ['统计图表', '地点热力图']
        },
        {
          path: '/hotPeople',
          component: hotPeople,
          meta: ['统计图表', '热点人物柱状图']
        },
        {
          path: '/hotAgency',
          component: hotAgency,
          meta: ['统计图表', '热点机构柱状图']
        },
        {
          path: '/hotResource',
          component: hotResource,
          meta: ['统计图表', '热点来源柱状图']
        },
        {
          path: '/hotSource',
          component: hotSource,
          meta: ['统计图表', '活跃媒体饼状图']
        },
        {
          path: '/keywordTrend',
          component: keywordTrend,
          meta: ['统计图表', '关键词正负倾向图']
        },
        {
          path: '/peopleRelationship',
          component: peopleRelationship,
          meta: ['统计图表', '人物关系图']
        },
        {
          path: '/forecast',
          component: forecast,
          meta: ['统计图表', '预测图']
        }
      ]
    }
  ]
})
