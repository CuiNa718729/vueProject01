<template>
    <div class="position-banner wh">
      <div class="about-us">
        <ul class="about-list">
          <li v-for="(item, index) in aboutList" :key="index"
              @click="addActive(item, index)"
              :class="{active1:index == currentIndex}">
            {{ item }}
            <i class="active-left"></i>
            <i class="active-right"></i>
          </li>
        </ul>
        <div class="about-content" v-if="currentIndex == 0">
          <div class="about-title">
            <span>集团简介</span>
          </div>
          <div class="about-detail">
            <p>中科富融集团(简称中科富融)是一家以“信息科技+人工智能+天基网络”为核心的集团化经营管理公司,是一家年轻的、极富生命力和发展空间的综合性产业集团。公司以科技板块作为集团发展的先导,坚持以国际、国内趋势性的前沿技术应用为科技项目,打造集团公司持续领先的科技竞争力,孵化一批具备绝对竞争力的科技项目,并面向全球市场进行产业化之路。</p>
            <p>中科富融与中科院计算所、中科院导航总体部、中国航天五院以及北京交通大学成立联合实验室,引进中国人工智能、大数据、云计算卫星应用等领域具备绝对竞争力的研发团队，整合各方优势,强强联合,构建了产、学、研、用一体化的发展思路,同时也积累了与中国领先科研院所合作的宝贵经验。</p>
          </div>
        </div>
        <div class="about-content" v-else-if="currentIndex == 1">
          <div class="about-title">
            <span>集团资质</span>
          </div>
          <ul class="contact-list">
            <li></li>
            <li></li>
            <li></li>
          </ul>
          <ul class="contact-list1">
            <li></li>
            <li></li>
            <li></li>
          </ul>
        </div>
        <div class="about-content" v-else-if="currentIndex == 2">
          <div class="about-title">
            <span>联系我们</span>
          </div>
          <ul class="call-info">
            <li>
              <div></div>
              <span>地址</span>
              <p>北京市东城区白桥大街15号嘉禾国信大厦CD座5层</p>
            </li>
            <li>
              <div></div>
              <span>邮箱</span>
              <p>caoxiaole@zfjy168.com</p>
            </li>
            <li>
              <div></div>
              <span>联系人</span>
              <p>曹先生</p>
            </li>
            <li>
              <div></div>
              <span>电话</span>
              <p>400-110-1666</p>
            </li>
          </ul>
        </div>
      </div>
    </div>
</template>

<script>
export default {
  name: 'aboutUs',
  data () {
    return {
      currentIndex: 0,
      aboutList: ['集团简介', '集团资质', '联系我们']
    }
  },
  methods: {
    addActive (item, index) {
      this.currentIndex = index
    }
  }
}
</script>

<style scoped>
  .wh{
    width: 1073px;
    height: 598px;
  }
  .about-us{
    width: 1073px;
    height: 598px;
    background: url("../assets/images/about/about_bg.png") no-repeat center;
    background-size: 1073px 598px;
  }
  .about-list{
    position: absolute;
    top: 19px;
    left: 122px;
    overflow: hidden;
    transform: skew(-25deg);
  }
  .about-list li{
    position: relative;
    width: 107px;
    height: 46px;
    font-size: 18px;
    color: #f8b5e9;
    text-align:  center;
    line-height: 46px;
    transform: skew(25deg);
    cursor: pointer;
  }
  .active1{
    font-size: 20px!important;
    color: #fff!important;
  }
  .active1 .active-left{
    position: absolute;
    left: 0;
    top: 16px;
    width: 7px;
    height: 14px;
    background: url("../assets/images/about/about_icon1.png") no-repeat center;
    background-size: 7px 14px;
  }
  .active1 .active-right{
    position: absolute;
    right: 0;
    top: 16px;
    width: 7px;
    height: 14px;
    background: url("../assets/images/about/about_icon2.png") no-repeat center;
    background-size: 7px 14px;
  }
  .about-content{
    margin-left: 114px;
  }
  .about-title{
    padding-left: 120px;
    height: 94px;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 28px;
  }
  .about-title span{
    padding-right: 38px;
    padding-top: 5px;
  }
  .about-detail{
    width: 589px;
    margin: 45px auto 0;
    color: #cbc9cc;
    line-height: 30px;
    text-indent: 2em;
    text-align: justify;
  }
  .contact-list{
    margin-left: 183px;
    margin-top: 45px;
    width: 650px;
    height: 130px;
    overflow: hidden;
    display: flex;
    justify-content: space-between;
  }
  .contact-list li{
    width: 200px;
    height: 136px;
  }
  .contact-list li:nth-of-type(1){
    background: url("../assets/images/about/about_pic1.png") no-repeat center;
    background-size: 200px 136px;
  }
  .contact-list li:nth-of-type(2){
    background: url("../assets/images/about/about_pic2.png") no-repeat center;
    background-size: 200px 136px;
  }
  .contact-list li:nth-of-type(3){
    background: url("../assets/images/about/about_pic3.png") no-repeat center;
    background-size: 200px 136px;
  }
  .contact-list1{
    margin-left: 130px;
    margin-top: 45px;
    width: 650px;
    height: 130px;
    overflow: hidden;
    display: flex;
    justify-content: space-between;
  }
  .contact-list1 li{
    width: 200px;
    height: 136px;
  }
  .contact-list1 li:nth-of-type(1){
    background: url("../assets/images/about/about_pic1.png") no-repeat center;
    background-size: 200px 136px;
  }
  .contact-list1 li:nth-of-type(2){
    background: url("../assets/images/about/about_pic2.png") no-repeat center;
    background-size: 200px 136px;
  }
  .contact-list1 li:nth-of-type(3){
    background: url("../assets/images/about/about_pic3.png") no-repeat center;
    background-size: 200px 136px;
  }
  .call-info{
    margin-left: 169px;
    margin-top: 45px;
    width: 650px;
    overflow: hidden;
    display: flex;
    justify-content: space-between;
  }
  .call-info li{
    width: 150px;
    color: #cbc9cc;
    display: flex;
    align-items: center;
    flex-direction: column;
    line-height: 24px;
  }
  .call-info li>div{
    margin-bottom: 20px;
    width: 95px;
    height: 95px;
  }
  .call-info li:nth-of-type(1) div{
    background: url("../assets/images/about/about_address.png") no-repeat center;
    background-size: 95px 95px;
  }
  .call-info li:nth-of-type(2) div{
    background: url("../assets/images/about/about_email.png") no-repeat center;
    background-size: 95px 95px;
  }
  .call-info li:nth-of-type(3) div{
    background: url("../assets/images/about/about_people.png") no-repeat center;
    background-size: 95px 95px;
  }
  .call-info li:nth-of-type(4) div{
    background: url("../assets/images/about/about_num.png") no-repeat center;
    background-size: 95px 95px;
  }
</style>
