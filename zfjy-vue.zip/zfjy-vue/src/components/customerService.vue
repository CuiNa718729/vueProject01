<template>
    <div class="position-banner wh">
      <div class="customer-service">
        <div class="customer-content">
          <p class="customer-title">客服中心</p>
          <ul class="customer-qq">
            <li>
              <div class="customer-phone">
                <span style="font-size:16px">客服电话</span>
                <p>400-110-1666</p>
              </div>
            </li>
            <li>
              <div class="customer-poker">
                <span style="font-size: 16px">AK棋牌客服群</span>
                <p>700479506</p>
              </div>
            </li>
            <li>
              <div class="customer-quiz">
                <span style="font-size: 16px">球爷客服群</span>
                <p>537605909</p>
              </div>
            </li>
          </ul>
          <div class="customer-intro">
            <span>客服团队</span>
            <p>客服中心是公司服务用户、了解用户心声、维护用户的重要桥梁与纽带。中富竞娱文体科技有限公司成立于2018年，公司拥有专业的客服团队，秉承“用我们专业的知识 为您提供贴心服务”的理念，坚持以100％受理、100％处理、100％回复、100％满意的服务准则提高客服工作整体质量及用户满意度。客服团队按照服务项目组成严密的工作流程，从不同方面解决客户难题，同时保证服务效率和质量。</p>
            <span>专业培训</span>
            <p>中富竞娱文体科技有限公司客服团队经过服务意识、服务用语、专业知识等全面、专业的培训，实现了服务内容的拓展、服务渠道的丰富、服务方式的创新、服务质量的提升等一系列发展和跨越。在客服团队的管理上，我公司拥有严格的纪律约束，保证客服人员以专业的姿态应对客户，将每位客户都视为VIP客户来对待，用心服务。</p>
          </div>
        </div>
      </div>
    </div>
</template>

<script>
export default {
  name: 'customerService'
}
</script>

<style scoped>
  .wh{
    width: 1211px;
    height: 599px;
  }
  .customer-service{
    width: 1211px;
    height: 599px;
    font-size: 20px;
    background: url("../assets/images/service/service_bg.png") no-repeat center;
    background-size: 1211px 599px;
  }
  .customer-content{
    margin-left: 454px;
  }
  .customer-title{
    font-size: 28px;
    line-height: 74px;
  }
  .customer-qq{
    margin-top: 30px;
    overflow: hidden;
    width: 663px;
    display: flex;
    justify-content: space-between;
  }
  .customer-qq li{
    width: 208px;
    height: 52px;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #b5337d;
  }
  .customer-phone{
    padding-left: 40px;
    background: url("../assets/images/service/service_phone.png") no-repeat left center;
    background-size: 40px 32px;
  }
  .customer-poker{
    padding-left: 40px;
    background: url("../assets/images/service/service_poker.png") no-repeat left center;
    background-size: 40px 32px;
  }
  .customer-quiz{
    padding-left: 40px;
    background: url("../assets/images/service/service_quiz.png") no-repeat left center;
    background-size: 40px 32px;
  }
  .customer-intro{
    width: 623px;
    overflow: hidden;
  }
  .customer-intro span{
    display: block;
    margin-top: 24px;
    color: #ba3382;
    font-weight: bold;
    padding-left: 28px;
  }
  .customer-intro span:nth-of-type(1){
    background: url("../assets/images/service/service_team.png") no-repeat left center;
    background-size: 28px 20px;
  }
  .customer-intro span:nth-of-type(2){
    background: url("../assets/images/service/service_train.png") no-repeat left center;
    background-size: 28px 20px;
  }
  .customer-intro p{
    text-align: justify;
    font-size: 16px;
    line-height: 26px;
    color: #cbc9cc;
  }
</style>
