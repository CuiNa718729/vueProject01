<template>
  <div class="clearfix">
    <ul class="nav clearfix">
      <li v-for="(item, index) in navList"
          :key="index"
          @click="addActive(item, index)"
          :class="{active:index == current}">
        <span>{{ item.name }}</span>
        <div class="li-hover"></div>
      </li>
    </ul>
   <!-- <transition enter-active-class="zoomIn" leave-active-class="zoomOut" mode="out-in">
        <router-view class="animated" v-if="$route.meta.keepAlive"></router-view>
    </transition>-->
    <transition enter-active-class="zoomIn" leave-active-class="zoomOut">
      <router-view class="animated"></router-view>
    </transition>
    <!--<router-view class="animated"></router-view>-->
  </div>
</template>

<script>
export default {
  name: 'navBar',
  data () {
    return {
      current: 0,
      navList: [{
        name: '新闻中心',
        address: '/companyNews'
      }, {
        name: '公司简介',
        address: '/companyIntroduce'
      }, {
        name: '主营业务',
        address: '/mainBusiness'
      }, {
        name: '招贤纳士',
        address: '/recruitment'
      }, {
        name: '集团简介',
        address: '/aboutUs'
      }, {
        name: '客服中心',
        address: '/customerService'
      }]
    }
  },
  mounted () {
    this.selectTabs()
  },
  methods: {
    addActive (item, index) {
      this.current = index
      this.$router.push(item.address)
    },
    selectTabs () {
      //  解决页面刷新导航栏重置问题
      const route = this.$route.name
      switch (route) {
        case 'companyNews':
          this.current = 0
          break
        case 'companyIntroduce':
          this.current = 1
          break
        case 'mainBusiness':
          this.current = 2
          break
        case 'qualification':
          this.current = 3
          break
        case 'recruitment':
          this.current = 4
          break
        case 'aboutUs':
          this.current = 5
          break
        case 'customerService':
          this.current = 6
          break
      }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .nav{
    float: right;
    margin-top: 26px;
    margin-right: 32px;
    z-index: 200;
  }
  .nav li{
    position: relative;
    cursor: pointer;
    float: left;
    width: 130px;
    height: 56px;
    line-height: 56px;
    background-color: #3640a7;
    transform: skew(-16deg);
    margin-left: 5px;
    font-size: 22px;
    color: #c2c7fa;
  }
  .nav li span{
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    margin: auto;
    display: block;
    text-align: center;
    transform: skew(16deg);
    z-index: 100;
  }
  .nav li .li-hover{
    width: 0;
    height: 100%;
    position: absolute;
    top: 0;
    left: 0;
    transition: all 1s;
    z-index: 99;
  }
  .nav li:hover .li-hover{
    width: 100%;
    background-color: #ba3382;
  }
  .active{
    color: #fff!important;
    background-color: #ba3382!important;
  }
  @media screen and (max-width: 1366px) {
    .nav{
      margin-top: 15px;
    }
    .nav li{
      position: relative;
      cursor: pointer;
      float: left;
      width: 92px;
      height: 40px;
      line-height: 40px;
      background-color: #3640a7;
      transform: skew(-16deg);
      margin-left: 5px;
      font-size: 16px;
      color: #c2c7fa;
    }
  }
</style>
