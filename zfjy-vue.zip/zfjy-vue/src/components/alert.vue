<template>
  <div class="mask" v-show="visible">
    <div class="modalDiv">
      <div class="parent">
        <img @click="close" class="close" src="../assets/images/close.png" alt="">
        <img class="modal" src="../assets/images/modal.png" alt="">
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'alert',
  data () {
    return {
      visible: true
    }
  },
  methods: {
    close () {
      this.visible = false
    }
  }
}
</script>
<style scoped>
  .mask{
    width: 100%;
    height: 100%;
    position: fixed;
    background: rgba(0,0,0,.53);
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 300;
  }
  .modalDiv{
    position: relative;
    width: 100%;
    height: 100%;
  }
  .parent{
    width: 723px;
    height: 702px;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    margin: auto;
  }
  .mask .modal{
    width: 723px;
    height: 702px;
  }
  .close{
    width: 39px;
    height: 42px;
    position: absolute;
    top: -20px;
    right: -50px;
  }
</style>
