<template>
  <div class="position-banner wh">
    <div class="recruitment-job">
      <ul class="tab-list">
        <li v-for="(item, index) in jobList" :key="index"
            @click="addActive(item, index)"
            :class="{active:index == current}">
          <span>{{ item }}</span>
        </li>
      </ul>
      <div class="job-content" v-if="current == 0">
        <div class="job-name">
          <span>后台产品经理</span>
          <p>投递邮箱：caoxiaole@zfjy168.com</p>
        </div>
        <div class="job-detail-scroll">
          <div class="job-detail">
            <span class="response">岗位职责</span>
            <p>
              1、负责公司微信、微博公众号的日常运营工作，增加粉丝数，提高关注度; <br/>
              2、根据制定的内容方向发布各种符合要求的优质、有传播性的内容; <br/>
              3、策划执行新媒体互动活动，提高粉丝活跃度，与粉丝做好互动，对粉丝的网络行为进行分析与总结; <br/>
              4、挖掘和分析微信用户需求，收集用户反馈，分析用户行为及需求，即时掌握当下热门话题; <br/>
              5、寻找网络渠道进行合作推广，提升曝光率及品牌知名度; <br/>
              6、跟踪新媒体推广效果，分析数据并及时反馈跟进 <br/>
              7、根据数据分析结果，提出建议，并制定与新媒体有关的的运营计划及推广方案。<br/>
            </p>
            <span class="claim">任职要求</span>
            <p>
              1、拥有互联网营销思维，对市场动态敏感，思维活跃，2年以上工作经验; <br/>
              2、具备游戏类APP推广与运营的资源（人脉资源、整合资源）优先考虑;<br/>
              3、拥有市场营销或产品开发类工作的经历; <br/>
              4、关注社会热点，热爱互联网，有较强的文字编辑功底，擅长新媒体网络软文编辑能力; <br/>
              5、广告学、新闻及中文相关专业本科以上学历优先，文字功底深厚，思维敏捷清晰者优先; <br/>
              6、有互联网信仰，最好是重度使用者，制定新媒体推广计划，执行力强; <br/>
              7、熟悉新媒体，对微博、微信如数家珍，熟悉大号，运营过微博草根号、微信公众号更好; <br/>
              8、有判断力，对热点事件能分析，有自身独到的见解; <br/>
            </p>
          </div>
        </div>
      </div>
      <div class="job-content" v-if="current == 1">
        <div class="job-name">
          <span>竞猜产品策划</span>
          <p>投递邮箱：caoxiaole@zfjy168.com</p>
        </div>
        <div class="job-detail-scroll">
          <div class="job-detail">
            <span class="response">岗位职责</span>
            <p>
              1、负责移动端体育竞技类游戏产品的需求分析和产品交互设计。 <br/>
              2、了解用户需求，分析竞争对手动态和市场动态，执行产品路线图，提出产品需求和改良意见，形成原型图和需求策划文案等工作。 <br/>
              3、可以输出思路清晰、目标明确的产品文档，能够熟练使用主流的产品设计工具。<br/>
              4、负责对体育竞技游戏产品的游戏性和可玩性评估，分析游戏发展方向，完成分析评测工作并预计其今后表现; <br/>
              5、与合作厂商协作制定游戏产品开发时间表，根据市场运营情况提出修改建议和需求;<br/>
            </p>
            <span class="claim">任职要求</span>
            <p>
              1、全日制本科或以上学历，3年以上互联网体育竞技游戏行业产品经验;<br/>
              2、有移动互联网工作经验者优先;<br/>
              3、爱好体育，资深球迷优先;<br/>
              4、逻辑强，能够理性分析；情商高，能够感性认知；口才好，能够通情达理;<br/>
              5、擅于团队合作，乐观开朗，有正能量，谦虚好学，抗压能力强;<br/>
              6、关注细节，完美主义，头脑灵活;<br/>
            </p>
          </div>
        </div>
      </div>
      <div class="job-content" v-else-if="current == 2">
        <div class="job-name">
          <span>游戏策划</span>
          <p>投递邮箱：caoxiaole@zfjy168.com</p>
        </div>
        <div class="job-detail-scroll">
          <div class="job-detail">
            <span class="response">岗位职责</span>
            <p>
              1、负责对各类引进游戏产品的游戏性和可玩性评估，分析游戏发展方向，完成分析评测工作并预计其今后表现；<br/>
              2、负责对市场信息搜集和整理，对于市场特定产品、公司或者行业趋势调研和分析；<br/>
              3、与合作游戏厂商的项目经理协作制定游戏产品开发时间表，产品开发过程中进行监督，根据市场运营情况提出修改建议和需求；<br/>
              4、产品上线后针对出现的问题进行跟踪、反馈、处理。对产品问题引起的事故及时跟进并制定具体的解决方案；<br/>
              5、制定游戏运营策略及相关活动，负责版本进度及与厂商沟通并进行把控。<br/>
            </p>
            <span class="claim">任职要求</span>
            <p>
              1、熟悉网页游戏，对网络游戏运营有深入的了解。<br/>
              2、对市场和运营的数据采集和分析有很强的能力，能及时进行游戏运营策略的优化；<br/>
              3、熟悉游戏市场及产品特性，了解行业发展趋势，了解玩家的爱好及其各类特征；<br/>
              4、善于组织和控制项目计划的进度、质量和成本；<br/>
              5、做事认真细致，精益求精，严于律己，具有高度责任感和团队合作精神；<br/>
              6、具有较强组织协调能力，优秀的沟通能力、计划与执行能力；<br/>
              7、学习能力强，逻辑清晰，思路开阔；<br/>
              8、有游戏项目成功开发或运营经验优先；<br/>
              9、大学本科及以上学历，有3年以上游戏行业工作经验。<br/>
            </p>
          </div>
        </div>
      </div>
      <div class="job-content" v-else-if="current == 3">
        <div class="job-name">
          <span>UI设计师</span>
          <p>投递邮箱：caoxiaole@zfjy168.com</p>
        </div>
        <div class="job-detail-scroll">
          <div class="job-detail">
            <span class="response">岗位职责</span>
            <p>
              1、参与手机界面，平面宣传品等的创意设计；<br/>
              2、完成对照片、图片的后期处理；<br/>
              3、负责APP整体的美术设计、创意设计和制作工作；具有良好的网页界面整体审美观及创新设计能力；<br/>
              4、参与制定APP作品的栏目结构、设计风格定位，设计并负责其实施；<br/>
              5、领导安排的其他相关工作。<br/>
            </p>
            <span class="claim">任职要求</span>
            <p>
              1、具有丰富的APP创意设计制作经验，能够进行Flash动画设计制作，精通网页设计，宣传册设计；<br/>
              2、具有良好的沟通、协作能力和丰富的团队工作经验，对设计工作感兴趣，逻辑思维清晰，做事认真、细致，能承受较大的工作压力；<br/>
              3、熟悉网站制作流程,有较丰富的网站设计和制作经验，能独立完成网站页面的设计，制作；<br/>
              4、精通HTML、CSS、JAVASCRIPT、DIV+CSS等网页设计技术，能独立完成静态页面制作和网站页面规划；<br/>
              5、熟练使用Photoshop、Flash等图形设计软件和Dreamweaver等网页编辑软件；<br/>
              6、善于沟通，较强独立工作能力，工作积极主动,认真细致,责任心强。<br/>
              7、2年以上工作经验，有设计APP设计经验或美术院校毕业优先；<br/>
              8、面试需携带作品。
            </p>
          </div>
        </div>
      </div>
      <div class="job-content" v-else-if="current == 4">
        <div class="job-name">
          <span>新媒体推广经理</span>
          <p>投递邮箱：caoxiaole@zfjy168.com</p>
        </div>
        <div class="job-detail-scroll">
          <div class="job-detail">
            <span class="response">岗位职责</span>
            <p>
              1、负责公司微信、微博公众号的日常运营工作，增加粉丝数，提高关注度；<br/>
              2、根据制定的内容方向发布各种符合要求的优质、有传播性的内容；<br/>
              3、策划执行新媒体互动活动，提高粉丝活跃度，与粉丝做好互动，对粉丝的网络行为进行分析与总结；<br/>
              4、挖掘和分析微信用户需求，收集用户反馈，分析用户行为及需求，即时掌握当下热门话题；<br/>
              5、寻找网络渠道进行合作推广，提升曝光率及品牌知名度；<br/>
              6、跟踪新媒体推广效果，分析数据并及时反馈跟进；<br/>
              7、根据数据分析结果，提出建议，并制定与新媒体有关的的运营计划及推广方案。<br/>
            </p>
            <span class="claim">任职要求</span>
            <p>
              1、拥有互联网营销思维，对市场动态敏感，思维活跃，2年以上工作经验；<br/>
              2、具备游戏类APP推广与运营的资源（人脉资源、整合资源）优先考虑<br/>
              3、拥有市场营销或产品开发类工作的经历；<br/>
              4、关注社会热点，热爱互联网，有较强的文字编辑功底，擅长新媒体网络软文编辑能力<br/>
              5、广告学、新闻及中文相关专业本科以上学历优先，文字功底深厚，思维敏捷清晰者优先；<br/>
              6、有互联网信仰，最好是重度使用者，制定新媒体推广计划，执行力强；<br/>
              7、熟悉新媒体，对微博、微信如数家珍，熟悉大号，运营过微博草根号、微信公众号更好；<br/>
              8、有判断力，对热点事件能分析，有自身独到的见解。<br/>
            </p>
          </div>
        </div>
      </div>
      <div class="job-content" v-else-if="current == 5">
        <div class="job-name">
          <span>客服专员</span>
          <p>投递邮箱：caoxiaole@zfjy168.com</p>
        </div>
        <div class="job-detail-scroll">
          <div class="job-detail">
            <span class="response">岗位职责</span>
            <p>
              1、处理QQ、微信等社群的用户咨询，解答相关产品问题，提高用户活跃，增加用户粘性；<br/>
              2、客服电话的接听，解决用户的疑虑；<br/>
              3、客户相关信息的录入管理，建立客户档案；<br/>
              4、定期整理搜集客户反馈，进行客户需求分析；<br/>
              5、协助运营团队做好产品推广工作，增加粉丝数量；<br/>
            </p>
            <span class="claim">任职要求</span>
            <p>
              1、年龄18-26周岁，女士优先，大专以上学历，有过互联网客服运营经验优先；<br/>
              2、脾气好，耐性佳，待人和善，服务意识强；<br/>
            </p>
          </div>
        </div>
      </div>
      <div class="job-content" v-else-if="current == 6">
        <div class="job-name">
          <span>高级数值策划</span>
          <p>投递邮箱：caoxiaole@zfjy168.com</p>
        </div>
        <div class="job-detail-scroll">
          <div class="job-detail">
            <span class="response">岗位职责</span>
            <p>
              1、根据彩票游戏系统规则，进行系统底层框架的数学模型搭建和公式设计；<br/>
              2、制定出数据结构及相关数值公式编写，确保可用性和扩展性强；<br/>
              3、负责彩票游戏中各种数值的调整，进行游戏的平衡性、持续可发展性等调整；<br/>
              4、彩票游戏各系统实现的数值支持，游戏系统数值平衡的演算。<br/>
            </p>
            <span class="claim">任职要求</span>
            <p>
              1、大学本科以上学历，有游戏相关行业工作经验优先；<br/>
              2、有较清晰的逻辑思维与演算评估能力,流程思路清晰,有程序语言基础者优先；<br/>
              3、对高等数学、统计学、概率、心理学等与彩票相结合有较深理解者优先；<br/>
              4、能熟练使用Excel进行各种数值虚拟测算，能深入分析彩票游戏的经济和数值系统；<br/>
              5、可以独立使用EXCEL、SPSS建立大型数值模型；<br/>
              6、做事认真踏实，工作积极主动，能适应较大的工作压力，具有良好的创新精神、团队合作精神和艰苦的创业精神。<br/>
            </p>
          </div>
        </div>
      </div>
      <div class="job-content" v-else-if="current == 7">
        <div class="job-name">
          <span>运营数据分析</span>
          <p>投递邮箱：caoxiaole@zfjy168.com</p>
        </div>
        <div class="job-detail-scroll">
          <div class="job-detail">
            <span class="response">岗位职责</span>
            <p>
              1、规划及建立数据分析体系，对接产品、运营、风控的数据分析需求，从数据上辅助进行决策；<br/>
              2、负责渠道推广、运营活动的成本及收益分析，计算ROI，并提出优化建议；<br/>
              3、针对公司业务基础数据进行分析研究，搭建数据分析报表产品；提供策略和建议；<br/>
              4、协助各业务部门完成数据整理，分析与利用，及时提供支持方面的工作。<br/>
              5、对会员数据进行分析关联，分析客户消费行为特征，提供相应的运营及CRM建议，增强用户的黏性，促进客户增值；<br/>
              6、收集行业及竞争对手的流量数据、监测剖析，为决策提供参考<br/>
              7、对游戏数据深度分析，能够对游戏系统做相关专题研究及专项调研，提供版本追踪、版本评估及用户行为研究专题等报告，为公司经营决策、产品方向提供数据支持；<br/>
              8、负责构建数据挖掘、数据分析体系，负责分析研究和数据建模。<br/>
            </p>
            <span class="claim">任职要求</span>
            <p>
              1、大学统招本科及以上学历，统计学等理工科专业优先，有互联网行业经验优先，对数据化管理有一定理解；<br/>
              2、熟练掌握Excel，并掌握一种以上主流的统计分析工具：SQL/SAS/SPSS/R/Python,可以用ppt撰写分析报告等；<br/>
              3、逻辑严谨细致，有探索精神，工作踏实认真，有较强的沟通推动能力。<br/>
              4、熟悉游戏业务项目经验优先，熟悉数据分析的主要方法和思路，能够从纷繁的数据中找到有价值的数据并进行分析，最终推动将数据分析成果转化为生产力；
              资深游戏玩家，热爱游戏行业，对互联网快速变革高度敏感，理解新一代用户的特点。<br/>
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'recruitment',
  data () {
    return {
      current: 0,
      jobList: ['后台产品经理', '竞猜产品策划', '游戏策划', 'UI设计师', '新媒体推广经理', '客服专员', '高级数值策划', '运营数据分析']
    }
  },
  methods: {
    addActive (item, index) {
      this.current = index
    }
  }
}
</script>

<style scoped>
  .wh{
    width: 1212px;
    height: 599px;
  }
  .recruitment-job{
    width: 1212px;
    height: 599px;
    background: url("../assets/images/job/job_pic1.png") no-repeat center;
    background-size: 1212px 599px;
  }
  .job-content{
    margin-left: 453px;
  }
  .job-name{
    width: 727px;
    height: 74px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .job-name span{
    font-size: 26px;
    font-weight: bold;
  }
  .job-name p{
    font-size: 20px;
    color: #ba3382;
    font-weight: bold;
  }
  .job-detail-scroll{
    width: 640px;
    overflow: hidden;
  }
  .job-detail{
    margin-top: 24px;
    width: 690px;
    height: 440px;
    color: #cbc9cc;
    overflow-y: scroll;
  }
  .job-detail span{
    display: block;
    font-size: 20px;
    color: #ba3382;
    font-weight: bold;
    margin-bottom: 12px;
  }
  .job-detail p{
    width: 626px;
    font-size: 16px;
    line-height: 26px;
    margin-bottom: 28px;
    text-align: justify;
  }
  .response{
    padding-left: 26px;
    background: url("../assets/images/job/job_obligation.png") no-repeat left center;
    background-size: 26px 20px;
  }
  .claim{
    padding-left: 24px;
    background: url("../assets/images/job/job_require.png") no-repeat left center;
    background-size: 24px 20px;
  }
</style>
