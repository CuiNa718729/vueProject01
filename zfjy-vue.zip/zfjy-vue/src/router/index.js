import Vue from 'vue'
import Router from 'vue-router'

const navBar = r => require.ensure([], () => r(require('@/components/navBar')), 'navBar')
const companyNews = r => require.ensure([], () => r(require('@/components/companyNews')), 'companyNews')
const companyIntroduce = r => require.ensure([], () => r(require('@/components/companyIntroduce')), 'companyIntroduce')
const mainBusiness = r => require.ensure([], () => r(require('@/components/mainBusiness')), 'mainBusiness')
const recruitment = r => require.ensure([], () => r(require('@/components/recruitment')), 'recruitment')
const aboutUs = r => require.ensure([], () => r(require('@/components/aboutUs')), 'aboutUs')
const customerService = r => require.ensure([], () => r(require('@/components/customerService')), 'customerService')
const productConference = r => require.ensure([], () => r(require('@/page/productConference')), 'productConference')
const intelligenceCompetition = r => require.ensure([], () => r(require('@/page/intelligenceCompetition')), 'intelligenceCompetition')
const olympicSport = r => require.ensure([], () => r(require('@/page/olympicSport')), 'olympicSport')
const NotFoundView = r => require.ensure([], () => r(require('@/components/notFound')), 'NotFoundView')

Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [
    {
      path: '/',
      component: navBar,
      children: [{
        path: '',
        redirect: '/companyNews'
      }, {
        path: '/companyNews',
        name: 'companyNews',
        component: companyNews,
        meta: { keepAlive: true }
      }, {
        path: '/companyIntroduce',
        name: 'companyIntroduce',
        component: companyIntroduce
      }, {
        path: '/mainBusiness',
        name: 'mainBusiness',
        component: mainBusiness
      }, {
        path: '/recruitment',
        name: 'recruitment',
        component: recruitment
      }, {
        path: '/aboutUs',
        name: 'aboutUs',
        component: aboutUs
      }, {
        path: '/customerService',
        name: 'customerService',
        component: customerService
      }, {
        path: '/productConference',
        name: 'productConference',
        component: productConference
      }, {
        path: '/intelligenceCompetition',
        name: 'intelligenceCompetition',
        component: intelligenceCompetition
      }, {
        path: '/olympicSport',
        name: 'olympicSport',
        component: olympicSport
      }]
    }, {
      path: '*',
      component: NotFoundView
    }
  ]
})
