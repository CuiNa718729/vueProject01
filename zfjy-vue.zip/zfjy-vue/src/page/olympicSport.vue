<template>
  <div class="position-banner wh">
    <div class="news-specific">
      <div class="spec-title">
        <span>点燃激情，助力冬奥</span>
      </div>
      <div class="spec-content">
        <div class="spec-scroll">
          <div class="spec-detail">
            <p>为弘扬奥林匹克精神，传播奥林匹克文化，积极配合北京2022年冬奥会的举办，2018年5月11日下午两时，国际奥委会副主席、萨马兰奇体育发展基金会发起人萨马兰奇先生在北京展览馆宣布“2018奥林匹克博览会”正式启动。</p>
            <img src="../assets/images/news/3.png" alt="">
            <p>启动仪式上，萨马兰奇先生介绍了“2018奥林匹克博览会”的工作规划及五大战略支持机构。其中，极限智慧与奥林匹克—奥林匹克知识与智力大赛是本届奥林匹克博览会的十大特色项目之一。</p>
            <img src="../assets/images/news/4.png" alt="">
            <p>中富竞娱文体科技有限公司作为奥林匹克博览会的战略支持机构和极限智慧与奥林匹克项目的独家执行方，将与奥林匹克博览会携手于全球首次创立了以奥林匹克元素为背景的线下智力运动馆体系，打造基于奥林匹克知识传播的全新平台，宣扬奥林匹克精神与文化。</p>
          </div>
        </div>
      </div>
      <div class="text-button" @click="$router.go(-1)">
        <span>返回</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'olympicSport',
  data () {
    return {
      current: 0,
      jobList: ['智力运动馆', '项目精神', '项目支持单位', '项目场馆标识和定位', '奥林匹克智力运动馆功能', '奥林匹克智力运动馆规划', '奥林匹克智力运动馆效果图', '项目里程碑']
    }
  },
  methods: {
    addActive (item, index) {
      this.current = index
    }
  }
}
</script>

<style scoped>
  .wh{
    width: 1022px;
    height: 599px;
  }
  .news-specific{
    width: 1022px;
    height: 599px;
    background: url("../assets/images/news/BG.png") no-repeat center;
    background-size: 1022px 599px;
  }
</style>
