<template>
  <div class="position-banner wh">
    <div class="news-specific">
      <div class="spec-title">
        <span>中富竞娱产品发布会圆满落幕</span>
      </div>
      <div class="spec-content">
        <div class="spec-scroll">
          <div class="spec-detail">
            <p>5月11日，中富竞娱产品发布会在北京展览馆圆满召开，中富竞娱系列产品在近一年的研发与完善之后，将于近日正式发布上线。</p>
            <img src="../assets/images/news/5.png" alt="">
            <p>中富竞娱文体科技有限公司作为奥林匹克博览会的战略支持机构和极限智慧与奥林匹克项目的独家执行方，将在全国首次设立线下智力运动训练营体系，以线上线下相结合的形式创新奥林匹克传播方式、构建全民奥运知识平台。</p>
            <p>极限智慧与奥林匹克项目负责人张孝雨向记者介绍，在未来五年内，将以国际化的研发团队和知识专家团队为支撑，打造围绕智力、文化、体育三位一体的产品矩阵。</p>
            <img src="../assets/images/news/6.png" alt="">
            <p>“我们将运用互联网突破赛事举办的地理限制，采取有奖问答提升群众的参与热情，设置竞技排名给予参与者荣誉感，并精准打造基于奥林匹克知识传播的全新平台。以此加深不同阶层、不同年龄、不同群体对奥林匹克精神与文化的理解，这也将点燃民众奥运激情，助力奥林匹克精神在中国的广泛传播。” 张孝雨如是说道。</p>
          </div>
        </div>
      </div>
      <div class="text-button" @click="$router.go(-1)">
        <span>返回</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'productConference'
}
</script>

<style scoped>
  .wh{
    width: 1022px;
    height: 599px;
  }
  .news-specific{
    width: 1022px;
    height: 599px;
    background: url("../assets/images/news/BG.png") no-repeat center;
    background-size: 1022px 599px;
  }
</style>
