<template>
  <div class="position-banner wh">
    <div class="news-specific">
      <div class="spec-title">
        <span>极限智慧与奥林匹克大赛在京启动</span>
      </div>
      <div class="spec-content">
        <div class="spec-scroll">
          <div class="spec-detail">
            <img src="../assets/images/news/1.png" alt="">
            <p>5月11日，国际奥委会副主席萨马兰奇先生在北京展览馆正式宣布极限智慧与奥林匹克大赛正式列入奥林匹克博览会十项重点项目，本次大会云集500余名行业专家及新闻媒体工作人员。本次发布会的成功举办，见证围绕 智力、文化、体育三位一体的产品新生态的创新和探索。必将进一步推动奥林匹克精神在中国的广泛传播。</p>
            <img src="../assets/images/news/2.png" alt="">
            <p>本次大会向前来参展嘉宾宣讲奥林匹克知识与智力大赛。大赛通过将奥林匹克元素和内容以在线竞技的方式进行，以更为生动、高效的方式快速传播奥林匹克知识，吸引更多年轻人参与、体验并分享奥林匹克的快乐。</p>
          </div>
        </div>
      </div>
      <div class="text-button" @click="$router.go(-1)">
        <span>返回</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'intelligenceCompetition',
  data () {
    return {
      current: 0,
      jobList: ['赛事意义', '赛事方案']
    }
  },
  methods: {
    addActive (item, index) {
      this.current = index
    }
  }
}
</script>

<style scoped>
  .wh{
    width: 1022px;
    height: 599px;
  }
</style>
