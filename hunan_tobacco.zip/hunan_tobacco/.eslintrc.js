module.exports = {
  "root": true,
  "extends": [
    "airbnb-base/legacy",
    "plugin:vue/recommended"
  ],
  "env": {
    "browser": true,
    "node": true
  },
  "plugins": [
    "vue"
  ],
  "parserOptions": {
    "parser": "babel-eslint",
    "sourceType": "module",
    "allowImportExportEverywhere": false,
    "codeFrame": false
  },
  "rules": {
    "no-param-reassign": 0,
    "max-len": [2, {
      "code": 120,
      "ignoreStrings": true,
      "ignoreTemplateLiterals": true,
      "ignoreRegExpLiterals": true,
      "ignorePattern": "data:image"
    }],
    "no-plusplus": 0,
    "vue/html-self-closing": 0,
    "comma-dangle": 0,
    "vue/require-default-prop": 0,
    "no-underscore-dangle": 0,
    "no-unused-expressions": 0,
    "array-callback-return": 0,
    "global-require": 0,
    "radix": 0,
    "no-console": 0,
    "consistent-return": 1,
    "class-methods-use-this": 0,
    "no-buffer-constructor": 1,
    "no-continue": 0,
    "camelcase": 0,
    "vue/attributes-order": 0,
    "no-use-before-define": ["error", { "functions": false, "classes": false }],
    "no-debugger": 1,
    "vue/attribute-hyphenation": 0,
    'linebreak-style': 'off'
  },
  "globals": {
  }
};



