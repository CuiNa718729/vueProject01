<template>
  <div id="app">
    <router-view
      v-wechat-title="$route.meta.title"
      img-set="/static/favicon.ico"></router-view>
  </div>
</template>

<script>
/* global WeixinJSBridge */

export default {
  name: 'App',
  created() {
    if (typeof (WeixinJSBridge) === 'undefined') {
      document.addEventListener('WeixinJSBridgeReady', () => {
        setTimeout(() => {
          WeixinJSBridge.invoke('setFontSizeCallback', { fontSize: 0 });
        }, 0);
      });
      return;
    }
    setTimeout(() => {
      WeixinJSBridge.invoke('setFontSizeCallback', { fontSize: 0 });
    }, 0);
  },
  methods: {}
};
</script>

<style scoped lang="scss">
  #app {
    height: 100%;
  }
</style>
