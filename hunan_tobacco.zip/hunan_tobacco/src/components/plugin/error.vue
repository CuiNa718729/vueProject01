<template>
  <transition name="error">
    <div
      v-if="open"
      class="error-box">
      <div class="alert-box">
        <img
          class="logo"
          :src="logo">
        <div
          class="text"
          v-html="text"></div>
        <div
          class="btn-box"
          flex="dir:left cross:center main:center"
          @click="_cancel">{{ cancelName }}</div>
      </div>
    </div>
  </transition>
</template>
<script>
import Vue from 'vue';

export default {
  _extend(options, func) {
    let modelBox = document.createElement('div');
    document.body.appendChild(modelBox);
    /* eslint-disable */
    let addModel = Vue.extend(this);
    let model = new addModel;
    /* eslint-enable */
    if (options.text) model.text = options.text;
    if (options.cancelName) model.cancelName = options.cancelName;
    if (options.cancelSa) model.cancelSa = options.cancelSa;
    model.func = func;
    model.cancel = options.cancel;
    model.$mount(modelBox);
  },
  install() {
    Vue.prototype.$error = (options, func) => {
      this._extend(options, func);
    };
  },
  data() {
    return {
      open: false,
      func: null,
      text: '',
      cancelName: '知道了',
      cancelSa: '',
      logo: require('./images/alert.png')
    };
  },
  mounted() {
    this.open = true;
  },
  methods: {
    _cancel() {
      if (typeof this.cancel === 'function') this.cancel();
      this.open = false;
    }
  }
};
</script>
<style lang="scss" scoped>
  .error-leave-active, .error-enter-active {
    transition: all .5s;
  }
  .error-leave-to, .error-enter {
    opacity: 0;
  }
  .error-enter-to {
    opacity: 1;
  }
  .error-box {
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background: rgba(0,0,0,0.5);
    z-index: 10000;
    .alert-box {
      position: fixed;
      width: 80%;
      border-radius: 6px;
      background: #ffffff;
      top: 40%;
      left: 50%;
      transform: translate(-50%,-50%);
      .logo {
        position: absolute;
        top: 0;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 190px;
      }
      .text {
        padding: 100px 0 50px 0;
        text-align: center;
        font-size: 30px;
        color: #000;
        line-height: 1.2;
      }
      .btn-box {
        border-top: 1px solid #ccc;
        padding: 20px 0;
        font-size: 38px;
        color: #FEAB22;
      }
    }
  }
</style>
