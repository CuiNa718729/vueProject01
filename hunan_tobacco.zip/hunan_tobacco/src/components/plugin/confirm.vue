<template>
  <transition name="confirm">
    <div
      v-if="open"
      class="confirm-box">
      <div class="alert-box">
        <div class="title">{{ title }}</div>
        <div
          class="btn-box"
          flex="dir:left cross:center box:mean">
          <span
            class="true"
            @click="_continue()">{{ submitName }}</span>
          <span
            class="false"
            @click="_cancel">{{ cancelName }}</span>
        </div>
      </div>
    </div>
  </transition>
</template>
<script>
import Vue from 'vue';

export default {
  _extend(options, func) {
    let modelBox = document.createElement('div');
    document.body.appendChild(modelBox);
    /* eslint-disable */
    let addModel = Vue.extend(this);
    let model = new addModel;
    /* eslint-enable */
    if (options.title) model.title = options.title;
    if (options.cancelName) model.cancelName = options.cancelName;
    if (options.submitName) model.submitName = options.submitName;
    model.func = func;
    model.cancel = options.cancel;
    model.close = options.close;
    model.$mount(modelBox);
  },
  install() {
    Vue.prototype.$confirm = (options, func) => {
      this._extend(options, func);
    };
  },
  data() {
    return {
      open: false,
      func: null,
      title: '',
      submitName: '确认',
      cancelName: '取消'
    };
  },
  mounted() {
    this.open = true;
  },
  methods: {
    _close() {
      if (typeof this.close === 'function') this.close();
      this.open = false;
    },
    _cancel() {
      if (typeof this.cancel === 'function') this.cancel();
      this.open = false;
    },
    _continue() {
      if (typeof this.func === 'function') this.func();
      this.open = false;
    }
  }
};
</script>
<style lang="scss" scoped>
  .confirm-leave-active, .confirm-enter-active {
    transition: opacity .5s;
  }
  .confirm-leave-to, .confirm-enter {
    opacity: 0;
  }
  .confirm-enter-to {
    opacity: 1;
  }
  .confirm-box {
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background: rgba(0,0,0,0.5);
    z-index: 10000;
    .alert-box {
      position: fixed;
      width: 80%;
      border-radius: 10px;
      background: #ffffff;
      top: 40%;
      left: 50%;
      transform: translate(-50%,-50%);
      .title {
        padding: 45px 0;
        text-align: center;
        font-size: 34px;
        line-height: 1.2;
      }
      .text {
        padding: 35px 20px;
      }
      .btn-box {
        border-top: 1px solid #DBDBDB;
        text-align: center;
        font-size: 32px;
        .true {
          color: #F29700;
        }
        &>span {
          padding: 20px 0;
          &:first-child {
            border-right: 1px solid #DBDBDB;
          }
        }
      }
    }
  }
</style>
