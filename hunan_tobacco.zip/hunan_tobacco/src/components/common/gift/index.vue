<template>
  <div
    v-if="swiperSlides.length > 0"
    class="gift">
    <swiper
      :options="swiperOption"
      ref="mySwiper">
      <swiper-slide
        v-for="(slide, index) in swiperSlides"
        :key="index">
        <div
          class="img"
          :style="{backgroundImage: `url(${slide.img})`}"
          @click="linkToOut(slide.url)"></div>
      </swiper-slide>
    </swiper>
  </div>
</template>

<script>
import { swiper, swiperSlide } from 'vue-awesome-swiper';
import 'swiper/dist/css/swiper.css';

export default {
  name: 'Gift',
  components: {
    swiper,
    swiperSlide
  },
  props: {
    type: {
      default: 1,
      type: Number
    }
  },
  data() {
    return {
      swiperOption: {
        autoplay: {
          disableOnInteraction: true
        },
        speed: 1200
      },
      swiperSlides: []
    };
  },
  computed: {
    swiper() {
      return this.$refs.mySwiper.swiper;
    }
  },
  mounted() {
    this.$http.post('/api/banner', {
      type: this.type
    }).then(res => {
      this.swiperSlides = res.data || [];
    });
  },
  methods: {
    linkToOut(url) {
      window.location.href = url;
    }
  }
};
</script>
<style scoped lang="scss">
  .gift {
    border-radius: 10px;
    overflow: hidden;
    .swiper-container {
      position: relative;
      height: 100%;
      .img {
        background: no-repeat center;
        background-size: cover;
        width: 100%;
        height: 100%;
      }
      .banner-swiper-pagination {
        position: absolute;
        z-index: 2;
        left: 0;
        bottom: 8px;
        width: 100%;
        text-align: center;
      }
    }
  }
</style>
