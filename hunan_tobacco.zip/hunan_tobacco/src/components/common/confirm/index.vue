<template>
  <transition name="confirm">
    <div
      v-if="value"
      class="confirm-box">
      <div class="alert-box">
        <div class="title">{{ title }}</div>
        <section class="text">
          <slot/>
        </section>
        <div
          class="btn-box"
          flex="dir:left cross:center main:justify">
          <span
            class="true"
            flex-box="1"
            @click="_continue()">{{ submitName }}</span>
          <span
            class="false"
            flex-box="1"
            @click="_cancel">{{ cancelName }}</span>
        </div>
      </div>
    </div>
  </transition>
</template>

<script>
export default {
  name: 'Confirm',
  props: {
    value: {
      type: Boolean,
    },
    title: {
      default: '标题',
      type: String
    },
    cancelName: {
      default: '取消',
      type: String
    },
    submitName: {
      default: '确定',
      type: String
    }
  },
  data() {
    return {};
  },
  created() {},
  methods: {
    _continue() {
      this.$emit('click-confirm');
    },
    _cancel() {
      this.$emit('input', false);
    }
  }
};
</script>
<style lang="scss" scoped>
  .confirm-leave-active, .confirm-enter-active {
    transition: opacity .5s;
  }
  .confirm-leave-to, .confirm-enter {
    opacity: 0;
  }
  .confirm-enter-to {
    opacity: 1;
  }
  .confirm-box {
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background: rgba(0,0,0,0.5);
    z-index: 10000;
    .alert-box {
      position: fixed;
      width: 80%;
      padding-top: 40px;
      border-radius: 10px;
      background: #ffffff;
      top: 40%;
      left: 50%;
      transform: translate(-50%,-50%);
      .title {
        text-align: center;
        font-size: 38px;
        font-weight: bold;
        line-height: 1.2;
      }
      .text {
        padding: 35px 40px;
      }
      .btn-box {
        border-top: 1px solid #DBDBDB;
        text-align: center;
        font-size: 36px;
        .true {
          color: #F29700;
        }
        &>span {
          padding: 20px 0;
          &:first-child {
            border-right: 1px solid #DBDBDB;
          }
        }
      }
    }
  }
</style>
