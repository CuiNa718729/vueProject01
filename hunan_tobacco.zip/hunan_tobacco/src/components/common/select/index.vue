<template>
  <transition name="select">
    <div
      v-if="value"
      class="select-box">
      <div class="alert-box">
        <div class="title">
          <span>{{ title }}</span>
          <span
            @click="_cancel"
            class="close">关闭</span>
        </div>
        <ul class="list">
          <li
            v-for="item in list"
            :key="item.id"
            @click="chooseSmoke(item.id)">
            <span
              v-if="isChoose(item.id)"
              class="iconfont icon-select"></span>
            <span>{{ item.name }}</span>
          </li>
        </ul>
        <div
          class="btn"
          @click="_continue">确定</div>
      </div>
    </div>
  </transition>
</template>

<script>
export default {
  name: 'Select',
  props: {
    value: {
      type: Boolean,
    },
    title: {
      default: '标题',
      type: String
    },
    list: {
      default: null,
      type: Array
    },
    defaultList: {
      default: null,
      type: Array
    }
  },
  data() {
    return {
      selectList: []
    };
  },
  watch: {
    value(val) {
      if (val) this.selectList = [...this.defaultList];
    }
  },
  methods: {
    isChoose(id) {
      return this.selectList.indexOf(id) > -1;
    },
    _continue() {
      this.$emit('click-sure', this.selectList);
    },
    _cancel() {
      this.$emit('click-close');
      this.selectList = [...this.defaultList];
      this.$emit('input', false);
    },
    chooseSmoke(id) {
      if (this.selectList.indexOf(id) > -1) {
        this.selectList.splice(this.selectList.findIndex(v => v === id), 1);
      } else {
        this.selectList.push(id);
      }
    }
  }
};
</script>
<style lang="scss" scoped>
  .select-leave-active, .select-enter-active {
    transition: opacity .5s;
  }
  .select-leave-to, .select-enter {
    opacity: 0;
  }
  .select-enter-to {
    opacity: 1;
  }
  .select-box {
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background: rgba(0,0,0,0.5);
    z-index: 10000;
    .alert-box {
      position: absolute;
      padding-bottom: 30px;
      width: 100%;
      background: #ffffff;
      left: 0;
      bottom: 0;
      .title {
        position: relative;
        width: 95%;
        padding: 30px;
        margin: 0 auto;
        text-align: center;
        font-size: 38px;
        font-weight: bold;
        border-bottom: 1px solid #DBDBDB;
        .close {
          position: absolute;
          top: 50%;
          right: 20px;
          transform: translate(0, -50%);
          font-size: 32px;
          color: #F29700;
        }
      }
      .list {
        margin: 30px 0;
        font-size: 30px;
        height: 220px;
        overflow-y: scroll;
        li {
          position: relative;
          line-height: 60px;
          text-align: center;
          margin-bottom: 20px;
          .icon-select {
            position: absolute;
            display: inline-block;
            top: 50%;
            left: 40px;
            transform: translate(0 ,-50%);
            font-size: 32px;
            color: #FEA71A;
          }
          &:last-child {
            margin-bottom: 0;
          }
        }
      }
      .btn {
        font-size: 38px;
        text-align: center;
        padding: 30px 0;
        background-color: #FEAB22;
        color: #fff;
      }
    }
  }
</style>
