<template>
  <div
    class="bottom-nav"
    flex="dir:left cross:center main:justify">
    <div
      class="scanning"
      @click="scanCode">
      <div class="icon scan"></div>
      <p>扫码验真</p>
    </div>
    <router-link
      v-for="item in navList"
      tag="div"
      :key="item.url"
      :to="item.url">
      <div
        class="icon"
        :class="[item.icon]"
        :style="{backgroundImage: `url(${item.bgUrl})`}"></div>
      <p>{{ item.name }}</p>
    </router-link>
  </div>
</template>

<script>
import wx from 'weixin-js-sdk';
import NavList from './config/nav-list';

export default {
  name: 'BottomNav',
  data() {
    return {
      navList: NavList,
    };
  },
  methods: {
    scanCode() {
      wx.scanQRCode({
        needResult: 0, // 默认为0，扫描结果由微信处理，1则直接返回扫描结果，
        scanType: ['qrCode', 'barCode'], // 可以指定扫二维码还是一维码，默认二者都有
        success: (res) => {
          let result = res.resultStr; // 当needResult 为 1 时，扫码返回的结果
          console.log(result);
        }
      });
    }
  }
};
</script>
<style scoped lang="scss">
  .bottom-nav {
    position: fixed;
    z-index: 100;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 120px;
    border-top: 1px solid #eee;
    padding: 0 40px;
    background: #fff;
    &>div {
      padding-top: 10px;
    }
    .icon {
      margin: 0 auto 5px;
      width: 50px;
      height: 50px;
      background: no-repeat center;
      background-size: contain;
    }
    .scan {
      background-image: url("./images/scan.svg")
    }
    .router-link-active {
      .mall {
        background-image: url("./images/mall-select.svg") !important;
      }
      .activity {
        background-image: url("./images/activity-select.svg") !important;
      }
      .center {
        background-image: url("./images/center-select.svg") !important;
      }
    }
  }
</style>
