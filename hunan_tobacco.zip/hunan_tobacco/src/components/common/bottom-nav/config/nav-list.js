export default [
  {
    url: '/hunan/popular-activity',
    icon: 'activity',
    bgUrl: require('../images/activity.svg'),
    name: '热门活动'
  },
  {
    url: '/hunan/integral-mall',
    icon: 'mall',
    bgUrl: require('../images/mall.svg'),
    name: '积分商城'
  },
  {
    url: '/hunan/personal-center',
    icon: 'center',
    bgUrl: require('../images/center.svg'),
    name: '个人中心'
  }
];
