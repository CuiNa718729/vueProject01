<template>
  <div
    class="member-list"
    flex="dir:left cross:center main:justify">
    <div
      v-for="item in navList"
      :key="item.name"
      @click="goLink(item.outside, item.url)">
      <div
        class="iconfont"
        :class="[item.icon]"></div>
      <p class="name">{{ item.name }}</p>
    </div>
  </div>
</template>

<script>
import navList from './config/nav-list';

export default {
  name: 'MemberList',
  data() {
    return {
      navList: navList
    };
  },
  methods: {
    goLink(outside, url) {
      if (outside) {
        window.location.href = url;
      } else {
        // this.$router.push({ path: url });
      }
    }
  }
};
</script>
<style scoped lang="scss">
  .member-list {
    padding: 0 40px;
    border-radius: 10px;
    background: #fff;
    height: 200px;
    &>div {
      text-align: center;
      color: #666;
      font-size: 24px;
    }
    .iconfont {
      background: black;
      border-radius: 30px;
      height: 90px;
      width: 90px;
      margin: 0 auto 5px;
      font-size: 52px;
      line-height: 90px;
      color: #FFDD55;
    }
  }
</style>
