export default [
  {
    url: '//www.baidu.com',
    outside: true,
    icon: 'icon-leaf',
    name: '烟测评'
  },
  {
    url: '//www.baidu.com',
    outside: true,
    icon: 'icon-crown',
    name: '会员论坛'
  },
  {
    url: '/user/welfare',
    outside: false,
    icon: 'icon-welfare',
    name: '会员福利'
  },
  {
    url: '//www.baidu.com',
    outside: true,
    icon: 'icon-game',
    name: '会员游戏'
  }
];
