export default [
  {
    type: '1',
    name: '红包专区'
  },
  {
    type: '2',
    name: '优惠卷专区'
  },
  {
    type: '3',
    name: '体验专区'
  }
];
