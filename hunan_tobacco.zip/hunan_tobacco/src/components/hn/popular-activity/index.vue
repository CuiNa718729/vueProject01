<template>
  <div class="popular-activity">
    <gift :type="4"/>
    <section
      class="tab"
      flex="dir:left main:justify">
      <div
        v-for="item in tabList"
        :key="item.type"
        :class="{active: tabSelect === item.type}"
        @click="chooseTabType(item.type)">{{ item.name }}</div>
    </section>
    <section
      class="msg-list"
      v-infinite-scroll="loadMore"
      infinite-scroll-disabled="loading"
      infinite-scroll-distance="10">
      <div
        class="list"
        v-for="(item, index) in list"
        :key="index"
        @click="linkTo(item.url)">
        <div class="ad-logo">
          <img :src="item.image">
        </div>
        <div
          class="ad-msg-box"
          flex="dir:left cross:center main:justify">
          <p class="time">活动时间：{{ item.time }}</p>
          <div
            class="btn"
            flex-box="0">活动详情</div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
import gift from '../../common/gift';
import tabList from './config/tab-list';

export default {
  name: 'PopularActivity',
  components: {
    gift
  },
  data() {
    return {
      tabSelect: '',
      tabList: tabList,
      value: '',
      loading: false,
      list: []
    };
  },
  computed: {
    showTabNum() {
      let { type } = this.$route.query;
      return type;
    }
  },
  watch: {
    tabSelect(val) {
      this.getList(val);
    }
  },
  created() {
    this.tabSelect = this.showTabNum || '1';
  },
  methods: {
    async getList(val) {
      let result = await this.$http.post('/api/hot_activity', {
        type: val
      });
      if (result._http_status !== 200 || result.code !== 0) {
        this.$error({
          text: result.message
        });
        return;
      }
      this.list = result.data;
    },
    chooseTabType(type) {
      this.tabSelect = type;
    },
    linkTo(url) {
      window.location.href = url;
    },
    loadMore() {}
  }
};
</script>
<style scoped lang="scss">
  .popular-activity {
    .gift {
      height: 200px;
      border-radius: 0;
    }
    .tab {
      padding: 40px 50px;
      font-size: 32px;
      background-color: #fff;
      color: #555;
      border-bottom: 1px solid #EEE;
      .active {
        position: relative;
        color: #1A1A1A;
        &:after {
          position: absolute;
          bottom: -40px;
          left: 50%;
          transform: translate(-50%, 0);
          content: '';
          width: 50px;
          height: 4px;
          border-radius: 2px;
          background-color: #F39700;
        }
      }
    }
    .msg-list {
      padding: 30px;
      .list {
        margin-top: 25px;
        border-radius: 10px;
        box-shadow: 0 4px 3px #fff;
        overflow: hidden;
        &:first-child {
          margin-top: 0;
        }
        .ad-logo {
          border-top-left-radius: 10px;
          border-top-right-radius: 10px;
          img {
            display: block;
            width: 100%;
            height: auto;
          }
        }
        .ad-msg-box {
          padding: 30px 40px;
          background-color: #fff;
          font-size: 24px;
          color: #777;
          .btn {
            padding: 10px 25px;
            border-radius: 50px;
            border: 1px solid #E04034;
            color: #E04034;
          }
        }
        &:nth-child(2n) {
          .ad-msg-box .btn {
            border: 1px solid #8DDEEA;
            color: #8DDEEA;
          }
        }
      }
    }
  }
</style>
