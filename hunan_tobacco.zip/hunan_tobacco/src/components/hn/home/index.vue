<template>
  <div class="home">
    <user-info/>
    <swiper
      :options="swiperOption"
      ref="mySwiper">
      <swiper-slide
        v-for="(slide, index) in swiperSlides"
        :key="index">
        <img
          :src="slide.img"
          @click="linkToOut(slide.url)">
      </swiper-slide>
      <div
        class="swiper-pagination"
        slot="pagination"></div>
    </swiper>
    <section class="adv-list">
      <tobacco-message
        v-if="openTobacco"
        :tobacco-info="tobaccoInfo"/>
      <gift :type="3"/>
      <member-list/>
    </section>
    <no-scan v-if="!openTobacco"/>
    <div
      v-if="openTobacco"
      class="qr-code">
      <img
        class="code"
        src="./images/2.jpeg">
      <p># 关注橙杏公众号更多惊喜</p>
    </div>
    <gift-popup v-if="openTobacco"/>
  </div>
</template>

<script>
import userInfo from './user-info';
import tobaccoMessage from './tobacco-message';
import gift from '../../common/gift';
import memberList from '../../common/member-list';
import noScan from './no-scan';
import giftPopup from './gift-popup';
import { swiper, swiperSlide } from 'vue-awesome-swiper';
import 'swiper/dist/css/swiper.css';

export default {
  name: 'Home',
  components: {
    userInfo,
    tobaccoMessage,
    gift,
    memberList,
    noScan,
    giftPopup,
    swiper,
    swiperSlide
  },
  data() {
    return {
      swiperOption: {
        autoplay: {
          disableOnInteraction: true
        },
        speed: 1200,
        pagination: {
          el: '.swiper-pagination',
          bulletClass: 'my-bullet',
          bulletActiveClass: 'my-bullet-active',
        }
      },
      swiperSlides: [],
      openTobacco: false,
      tobaccoInfo: {},
      showGift: true
    };
  },
  computed: {
    swiper() {
      return this.$refs.mySwiper.swiper;
    },
    userInfo() {
      return this.$store.state.user;
    },
    isScan() {
      let { scan } = this.$route.query;
      return scan;
    }
  },
  mounted() {
    this.$http.post('/api/banner', {
      type: 2
    }).then(res => {
      this.swiperSlides = res.data || [];
    });
    if (this.isScan) return;
    this.$http.post('/api/product_info').then(res => {
      if (res._http_status !== 200 || res.code !== 0) return;
      this.tobaccoInfo = res.data || {};
      this.openTobacco = true;
    });
  },
  methods: {
    linkToOut(url) {
      window.location.href = url;
    }
  }
};
</script>
<style scoped lang="scss">
  .swiper-slide {
    img {
      display: block;
      width: 100%;
      height: auto;
    }
  }
  .adv-list {
    position: relative;
    z-index: 10;
    top: -30px;
    padding: 0 20px;
    margin-bottom: -30px;
    &>div {
      height: 200px;
      margin-bottom: 20px;
    }
  }
  .qr-code {
    margin: 50px 0;
    text-align: center;
    color: #444;
    font-weight: bold;
    font-size: 30px;
    .code {
      display: block;
      width: 300px;
      background: red;
      margin: 0 auto 20px;
    }
  }
</style>
<style lang="scss">
  .home {
    .swiper-pagination {
      bottom: 40px !important;
    }
    .my-bullet {
      position: relative;
      display: inline-block;
      margin-right: 10px;
      height: 8px;
      width: 40px;
      background: #fff;
      transform: skew(-50deg);
      &:last-child {
        margin-right: 0;
      }
      &.my-bullet-active {
        background: blue;
      }
    }
  }
</style>

let res=
