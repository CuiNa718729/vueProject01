<template>
  <div
    class="no-scan"
    flex="dir:left cross:stretch main:justify">
    <div
      class="scan-box"
      flex="dir:top main:justify"
      flex-box="1">
      <p>扫描烟盒上二维码验证真品</p>
      <div class="button">
        <span>扫码验真</span>
      </div>
    </div>
    <div
      class="logo"
      flex-box="0"></div>
  </div>
</template>

<script>
export default {
  name: 'NoScan',
  data() {
    return {};
  }
};
</script>
<style scoped lang="scss">
  .no-scan {
    padding: 70px 40px;
    background: #FFC64C;
    font-size: 38px;
    font-weight: bold;
    line-height: 1.6;
    color: #000;
    .scan-box {
      padding: 15px 0;
      .button {
        >span {
          display: inline-block;
          background: #fff;
          padding: 10px 40px;
          color: #F18A00;
        }
      }
    }
    .logo {
      width: 300px;
      height: 300px;
      margin-left: 30px;
      border-radius: 50%;
      background: #fff;
    }
  }
</style>
