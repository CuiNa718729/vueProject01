<template>
  <div
    v-if="closePopup"
    class="gift-popup">
    <have-gift
      v-if="giftList.length > 0"
      v-model="closePopup"
      :gift-list="giftList"/>
    <no-gift
      v-else
      v-model="closePopup"/>
  </div>
</template>

<script>
import haveGift from './have-gift';
import noGift from './no-gift';

export default {
  name: 'GiftPopup',
  components: {
    haveGift,
    noGift
  },
  data() {
    return {
      giftList: [],
      closePopup: false
    };
  },
  computed: {},
  async mounted() {
    let result = await this.$http.post('/api/draw');
    if (result._http_status !== 200 || result.code !== 0) return;
    this.giftList = result.data;
    this.closePopup = true;
  }
};
</script>
<style scoped lang="scss">
  .gift-popup {
    position: fixed;
    top: 0;
    left: 0;
    z-index: 1000;
    width: 100%;
    height: 100%;
    background: rgba(10, 2, 4, .7);
  }
</style>
