<template>
  <section class="no-gift">
    <div
      class="close iconfont icon-close"
      @click="closePopup"></div>
    <p>很遗憾</p>
    <p class="tip">您本次未中奖，再接再厉</p>
    <div class="logo"></div>
    <div
      class="btn"
      @click="closePopup">知道了</div>
  </section>
</template>

<script>
export default {
  name: 'NoGift',
  data() {
    return {};
  },
  methods: {
    closePopup() {
      this.$emit('input', false);
    }
  }
};
</script>
<style scoped lang="scss">
  .no-gift {
    position: fixed;
    top: 53%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 620px;
    border-radius: 10px;
    padding: 50px 40px 40px;
    font-size: 36px;
    text-align: center;
    background-color: #fff;
    .close {
      position: fixed;
      top: -120px;
      height: 84px;
      width: 84px;
      line-height: 84px;
      right: 0;
      text-align: center;
      font-size: 46px;
      background-color: rgba(255, 255, 255, .7);
      color: #000;
      border-radius: 50%;
      &:after {
        content: '';
        position: absolute;
        bottom: -36px;
        left: 50%;
        transform: translate(-50%, 0);
        width: 1px;
        height: 36px;
        background-color: rgba(255, 255, 255, .7);
      }
    }
    .tip {
      margin-top: 20px;
      font-size: 30px;
      color: #ff1414;
    }
    .logo {
      margin-top: 30px;
      height: 300px;
      background: url("./images/no-gift.png") no-repeat center;
      background-size: 44% auto;
    }
    .btn {
      margin-top: 30px;
      padding: 20px 0;
      border-radius: 10px;
      font-size: 40px;
      color: #fff;
      text-align: center;
      background-color: #FEA71A;
    }
  }
</style>
