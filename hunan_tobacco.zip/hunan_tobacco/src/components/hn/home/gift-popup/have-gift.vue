<template>
  <section class="have-gift">
    <div class="circle pink num_1"></div>
    <div class="circle blue num_2"></div>
    <div class="circle green num_3"></div>
    <div class="circle yellow num_4"></div>
    <div class="circle pink num_5"></div>
    <div
      class="close iconfont icon-close"
      @click="closePopup"></div>
    <div class="head"></div>
    <div class="voucher">
      <div class="left"></div>
      <div class="right"></div>
    </div>
    <div class="body">
      <div class="list-box">
        <div
          v-for="item in giftList"
          :key="item.name"
          class="gift-list"
          flex="dir:left">
          <div
            class="gift-img"
            flex-box="0"
            :style="{backgroundImage: `url(${item.img_url})`}">
          </div>
          <div
            class="gift-explain"
            flex="dir:top main:justify"
            flex-box="1">
            <p class="name">{{ item.award_name }}</p>
            <p class="time">{{ item.expire_time_message }}</p>
          </div>
        </div>
      </div>
    </div>
    <div
      class="btn"
      @click="getAllPrize">一键领取奖品</div>
  </section>
</template>

<script>
export default {
  name: 'HaveGift',
  props: {
    value: {
      type: Boolean
    },
    giftList: {
      type: Array
    }
  },
  data() {
    return {};
  },
  methods: {
    closePopup() {
      this.$emit('input', false);
    },
    async getAllPrize() {
      let result = await this.$http.post('/api/get_all_prize');
      if (result._http_status !== 200 || result.code !== 0) return;
      if (result.data && result.data.length > 0) {
        let idList = result.data.join('|');
        this.$router.push({ path: '/user/take-gift', query: { id: idList } });
        return;
      }
      this.closePopup();
      this.$nextTick(() => {
        this.$error({
          text: result.message
        });
      });
    }
  }
};
</script>
<style scoped lang="scss">
  .have-gift {
    position: fixed;
    top: 53%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 600px;
    border-radius: 10px;
    .circle {
      position: fixed;
      border-radius: 50%;
      z-index: -1;
      &.num_1 {
        width: 20px;
        height: 20px;
        left: -18px;
        top: -150px;
      }
      &.num_2 {
        width: 80px;
        height: 80px;
        top: -50px;
        left: -10px;
      }
      &.num_3 {
        width: 15px;
        height: 15px;
        top: -35px;
        left: 190px;
      }
      &.num_4 {
        width: 50px;
        height: 50px;
        left: 70px;
        top: -90px;
      }
      &.num_5 {
        width: 20px;
        height: 20px;
        left: -15px;
        top: 360px;
      }
    }
    .pink {
      background-color: #EDC1E9;
    }
    .blue {
      background-color: #AACEFF;
    }
    .green {
      background-color: #D1E47D;
    }
    .yellow {
      background-color: #FFC699;
    }
    .close {
      position: fixed;
      top: -120px;
      height: 84px;
      width: 84px;
      line-height: 84px;
      right: 0;
      text-align: center;
      font-size: 46px;
      background-color: rgba(255, 255, 255, .7);
      color: #000;
      border-radius: 50%;
      &:after {
        content: '';
        position: absolute;
        bottom: -36px;
        left: 50%;
        transform: translate(-50%, 0);
        width: 1px;
        height: 36px;
        background-color: rgba(255, 255, 255, .7);
      }
    }
    .head {
      height: 120px;
      background: #FDB900 url('./images/congratulate.png') no-repeat center;
      background-size: auto 60px;
    }
    .voucher {
      position: relative;
      width: 570px;
      height: 30px;
      margin: 0 auto;
      background: linear-gradient(#FDB900, #FEA71A);
      &:before {
        content: '';
        position: absolute;
        width: 100%;
        height: 1px;
        top: 50%;
        left: 0;
        transform: translate(0, -50%);
        border-top: 1px dashed #000;
      }
      .left, .right {
        position: absolute;
        z-index: -1;
        top: 50%;
        transform: translate(0, -50%);
        width: 60px;
        height: 60px;
        background: radial-gradient(
            rgba(255, 255, 255, 0) 0px,
            rgba(255, 255, 255, 0) 15px,
            #FEA71A 15px
        ) no-repeat;
      }
      .left {
        left: -15px;
        background-position: -30px 0;
      }
      .right {
        right: -15px;
        background-position: 30px 0;
      }
    }
    .body {
      padding: 20px 58px 40px;
      width: 100%;
      height: 530px;
      background-color: #FEA71A;
      .list-box {
        height: 100%;
        overflow-y: auto;
        .gift-list {
          padding: 25px 15px 25px 35px;
          margin-bottom: 25px;
          height: 140px;
          background: url("./images/gift-bg.png") no-repeat;
          background-size: cover;
          .gift-img {
            margin-right: 40px;
            height: 100%;
            width: 90px;
            background: no-repeat center;
            background-size: contain;
          }
          .gift-explain {
            color: #1A1A1A;
            .name {
              font-size: 30px;
            }
            .time {
              font-size: 24px;
            }
          }
          &:last-child {
            margin-bottom: 0;
          }
        }
      }
    }
    .btn {
      margin-top: 40px;
      padding: 20px 0;
      border-radius: 10px;
      font-size: 40px;
      color: #fff;
      text-align: center;
      background-color: #FEA71A;
    }
  }
</style>
