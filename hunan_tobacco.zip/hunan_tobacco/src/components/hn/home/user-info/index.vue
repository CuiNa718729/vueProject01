<template>
  <div
    class="user-info"
    flex="dir:left cross:center main:justify">
    <div
      class="user-photo-box"
      flex="dir:left main:justify">
      <div
        class="logo"
        :style="{backgroundImage: `url(${userInfo.user_img})`}"></div>
      <div
        class="user-message"
        flex="dir:top main:justify">
        <p>我的和币: {{ userInfo.coin }}</p>
        <p>我的经验值: {{ userInfo.xp }}</p>
      </div>
    </div>
    <div
      class="seal-box"
      flex="dir:top">
      <span
        v-if="userInfo.token"
        class="show-seal">{{ userInfo.token }}</span>
      <span
        v-if="userInfo.token"
        class="arc"></span>
      <span
        v-else
        class="add"
        @click="open = true">添加私人印鉴</span>
    </div>
    <confirm-box
      v-model="open"
      title="添加印鉴"
      @click-confirm="changeSeal">
      <div
        class="input-box"
        flex="dir:left cross:bottom main:justify">
        <div
          class="iconfont icon-seal"
          flex-box="0"></div>
        <input
          v-model="token"
          type="text"
          flex-box="1"
          placeholder="启用私人印鉴">
      </div>
    </confirm-box>
  </div>
</template>

<script>
import confirmBox from '@/components/common/confirm';

export default {
  name: 'UserInfo',
  components: {
    confirmBox
  },
  data() {
    return {
      open: false,
      token: ''
    };
  },
  computed: {
    userInfo() {
      return this.$store.state.user;
    }
  },
  mounted() {},
  methods: {
    async changeSeal() {
      if (this.token === '') {
        this.open = false;
        return;
      }
      let result = await this.$http.post('/api/update_token', {
        token: this.token
      });
      if (result._http_status === 200 && result.code === 0) {
        this.$store.commit('CHANGE_USER_PARAMS', {
          token: this.token
        });
      }
      this.open = false;
    }
  }
};
</script>
<style scoped lang="scss">
  .user-info {
    padding: 25px 50px;
    background-color: #fff;
    .user-photo-box {
      .logo {
        width: 85px;
        height: 85px;
        border-radius: 50%;
        margin-right: 40px;
        background: no-repeat center;
        background-size: cover;
      }
      .user-message {
        font-size: 24px;
        color: #1A1A1A;
      }
    }
    .seal-box {
      font-size: 24px;
      color: #1A1A1A;
      .add {
        padding: 15px 30px;
        color: #FC9D00;
        background-color: #FFF1E2;
        border-radius: 10px;
      }
      .show-seal {
        width: 130px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        text-align: center;
        color: #1A1A1A;
        font-size: 24px;
      }
      .arc {
        position: relative;
        top: -15px;
        width: 130px;
        height: 30px;
        border-bottom: 4px solid #FABC30;
        border-radius: 50%;
      }
    }
    .input-box {
      padding: 10px;
      width: 100%;
      border: 3px solid #F29700;
      .iconfont {
        padding-right: 25px;
        color: #FEAB22;
        font-size: 44px;
      }
      input {
        font-size: 32px;
        height: 50px;
        &[type='checkbox'] {
          margin-right: 10px;
        }
      }
    }
  }
</style>
