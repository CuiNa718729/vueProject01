<template>
  <div
    class="tobacco-message-box"
    flex="dir:left cross:center main:justify">
    <div
      class="tobacco-box"
      flex="dir:left main:justify">
      <div
        class="logo"
        :style="{backgroundImage: `url(${tobaccoInfo.product_image})`}"></div>
      <div
        class="tobacco-explain"
        flex="dir:top main:justify">
        <p class="name">{{ tobaccoInfo.product_name }}</p>
        <p class="code">该码为产品正确编码</p>
        <p
          class="number"
          v-if="tobaccoInfo.scan_count > 9">
          <span class="iconfont icon-tips"></span>
          <span>扫码次数：{{ tobaccoInfo.scan_count }}次</span>
        </p>
      </div>
    </div>
    <router-link
      class="see-more"
      tag="div"
      flex-box="0"
      to="/user/product-details">
      <div>查看详情</div>
    </router-link>
  </div>
</template>

<script>
export default {
  name: 'TobaccoMessageBox',
  props: {
    tobaccoInfo: {
      type: Object
    }
  },
  data() {
    return {};
  },
  computed: {},
};
</script>
<style scoped lang="scss">
  .tobacco-message-box {
    padding: 0 40px;
    border-radius: 10px;
    background-color: #fff;
    .tobacco-box {
      .logo {
        width: 85px;
        height: 135px;
        margin-right: 40px;
        background: no-repeat center;
        background-size: contain;
      }
      .tobacco-explain {
        padding-right: 15px;
        .name {
          width: 300px;
          height: 50px;
          line-height: 50px;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
          font-size: 30px;
          color: #0C0C0C;
          font-weight: bold;
        }
        .code {
          font-size: 26px;
          color: #FC4643;
        }
        .number {
          font-size: 24px;
          color: #39A2E2;
          .icon-tips {
            font-size: 24px;
          }
        }
      }
    }
    .see-more {
      padding: 10px 20px;
      font-size: 24px;
      color: #FEAB22;
      border: 1px solid #FEAB22;
      border-radius: 10px;
    }
  }
</style>
