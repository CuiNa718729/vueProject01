<template>
  <div class="personal-center">
    <section class="person-bg">
      <router-link
        tag="div"
        to="/user/data"
        class="user-box">
        <div
          class="photo"
          :style="{backgroundImage: `url(${userInfo.user_img})`}"></div>
        <p class="name">{{ userInfo.user_name }}</p>
      </router-link >
      <div
        class="user-seal"
        :class="{'show-token': userInfo.token}">
        <section
          v-if="userInfo.token">
          <span>{{ userInfo.token }}</span>
        </section>
        <section
          v-else
          flex="dir:left cross:center"
          @click="open = true">
          <span>添加私人印鉴</span>
          <span class="iconfont icon-add"></span>
        </section>
      </div>
    </section>
    <section
      class="user-value"
      flex="dir:left box:mean">
      <router-link
        class="gold"
        tag="div"
        to="/user/gold">
        <span>和币:</span>
        <span class="num">{{ userInfo.coin }}</span>
      </router-link>
      <router-link
        class="exp"
        tag="div"
        to="/user/exp">
        <span>经验值:</span>
        <span class="num">{{ userInfo.xp }}</span>
      </router-link>
    </section>
    <section class="user-nav not-get">
      <div
        class="top"
        flex="dir:left cross:center main:justify">
        <p class="name">我的礼品</p>
        <router-link
          tag="div"
          to="/user/gift"
          class="arrow">
          <span>查看全部</span>
          <span class="iconfont icon-arrow-right"></span>
        </router-link>
      </div>
      <div
        class="slot-gift"
        flex="dir:left cross:bottom main:justify">
        <router-link
          v-for="item in giftList"
          :key="item.name"
          tag="div"
          :to="{ path: '/user/gift', query: { type: item.type }}"
          :class="[ item.class ]">
          <p
            :style="{backgroundImage: `url(${item.bgUrl})`}"
            class="icon"></p>
          <p>{{ item.name }}</p>
          <div
            v-if="item.type === '2' && userInfo.not_get > 0"
            class="circle"></div>
          <div
            v-if="item.type === '3' && userInfo.not_sent > 0"
            class="circle"></div>
          <div
            v-if="item.type === '4' && userInfo.sent > 0"
            class="circle"></div>
        </router-link>
      </div>
    </section>
    <section class="user-nav card">
      <div
        class="top"
        flex="dir:left cross:center main:justify">
        <p class="name">我的卡劵</p>
        <router-link
          tag="div"
          to="/user/card"
          class="arrow">
          <span>查看全部</span>
          <span class="iconfont icon-arrow-right"></span>
        </router-link>
      </div>
      <div class="slot-voucher clearfix">
        <div
          v-for="(item, index) in cardList"
          v-if="index < 2"
          :key="item.ticketid"
          class="voucher-list"
          flex="dir:left cross:center main:justify">
          <span
            class="name"
            flex-box="0">{{ item.title }}</span>
          <div
            class="voucher-logo"
            :style="{ backgroundImage: `url(${item.image})` }"></div>
        </div>
      </div>
    </section>
    <gift :type="5"/>
    <section class="user-nav">
      <div
        class="top"
        flex="dir:left cross:center main:justify">
        <p class="name">我的商户</p>
        <div class="arrow">
          <span class="iconfont icon-arrow-right"></span>
        </div>
      </div>
    </section>
    <section class="user-nav">
      <router-link
        tag="div"
        to="/user/address"
        class="top"
        flex="dir:left cross:center main:justify">
        <p class="name">我的地址</p>
        <div class="arrow">
          <span class="iconfont icon-arrow-right"></span>
        </div>
      </router-link>
    </section>
    <section class="user-nav">
      <div
        class="top"
        flex="dir:left cross:center main:justify">
        <p class="name">我的评测</p>
        <div class="arrow">
          <span class="iconfont icon-arrow-right"></span>
        </div>
      </div>
    </section>
    <section class="user-nav">
      <router-link
        tag="div"
        to="/user/phone"
        class="top"
        flex="dir:left cross:center main:justify">
        <p class="name">修改手机号</p>
        <div class="arrow">
          <span>{{ userInfo.phone }}</span>
          <span class="iconfont icon-arrow-right"></span>
        </div>
      </router-link>
    </section>
    <confirm-box
      v-model="open"
      title="添加印鉴"
      @click-confirm="changeSeal">
      <div
        class="input-box"
        flex="dir:left cross:bottom main:justify">
        <div
          class="iconfont icon-seal"
          flex-box="0"></div>
        <input
          v-model="token"
          type="text"
          flex-box="1"
          placeholder="启用私人印鉴">
      </div>
    </confirm-box>
  </div>
</template>

<script>
import gift from '../../common/gift';
import giftList from './config/gift-list';
import confirmBox from '@/components/common/confirm';

export default {
  name: 'PersonalCenter',
  components: {
    gift,
    confirmBox
  },
  data() {
    return {
      open: false,
      token: '',
      giftList: giftList,
      cardList: []
    };
  },
  computed: {
    userInfo() {
      return this.$store.state.user;
    }
  },
  async created() {
    let result = await this.$http.post('/api/user_tickets');
    if (result._http_status !== 200 || result.code !== 0) {
      this.$error({
        text: result.message
      });
      return;
    }
    this.cardList = result.data || {};
  },
  methods: {
    async changeSeal() {
      if (this.token === '') {
        this.open = false;
        return;
      }
      let result = await this.$http.post('/api/update_token', {
        token: this.token
      });
      if (result._http_status === 200 && result.code === 0) {
        this.$store.commit('CHANGE_USER_PARAMS', {
          token: this.token
        });
      }
      this.open = false;
    }
  }
};
</script>

<style scoped lang="scss">
  .personal-center {
    .person-bg {
      position: relative;
      height: 330px;
      background: #fff url("./images/person-bg.png") no-repeat center;
      background-size: 100% 100%;
      .user-box {
        position: absolute;
        top: 50px;
        left: 50%;
        transform: translate(-50%, 0);
        text-align: center;
        .photo {
          margin: 0 auto 20px;
          width: 120px;
          height: 120px;
          border-radius: 50%;
          background: no-repeat center;
          background-size: cover;
        }
        .name {
          font-weight: bold;
          font-size: 32px;
          color: #1A1A1A;
        }
      }
      .user-seal {
        position: absolute;
        top: 20px;
        right: 40px;
        font-size: 28px;
        color: #7B4000;
        &.show-token span {
          display: inline-block;
          width: 140px;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
          text-align: center;
          color: #1A1A1A;
        }
        .iconfont {
          margin-left: 10px;
          font-size: 42px;
        }
      }
    }
    .user-value {
      background-color: #fff;
      padding: 20px 30px;
      .gold {
        border-right: 1px solid #7b4000;
      }
      .exp, .gold {
        padding: 15px 0;
        font-size: 30px;
        text-align: center;
        color: #444444;
        .num {
          color: #7B4000;
        }
      }
    }
    .user-nav {
      background-color: #fff;
      padding-left: 25px;
      &.card {
        margin-bottom: 15px;
      }
      &.not-get {
        margin-bottom: 15px;
      }
      .top {
        padding: 30px 30px 30px 0;
        border-bottom: 1px solid #DBDBDB;
        font-size: 30px;
        color: #1A1A1A;
        .arrow {
          color: #CBCBCB;
        }
        .iconfont {
          font-weight: bold;
          font-size: 30px;
        }
      }
      &:last-child {
        .top {
          border-bottom: none;
        }
      }
      .slot-gift {
        padding: 30px 95px 30px 70px;
        &>div {
          position: relative;
          font-size: 24px;
          color: #666;
          text-align: center;
          .icon {
            margin: 0 auto 10px;
            width: 50px;
            height: 50px;
            background: no-repeat center;
            background-size: contain;
          }
          .circle {
            position: absolute;
            width: 14px;
            height: 14px;
            top: -7px;
            right: -7px;
            background-color: #EA5722;
            border-radius: 50%;
          }
        }
      }
      .slot-voucher {
        .voucher-list {
          float: left;
          padding:30px 30px;
          width: 50%;
          &:first-child {
            border-right: 1px solid #DBDBDB;
          }
          .name {
            width: 170px;
            text-overflow:ellipsis;
            white-space: nowrap;
            overflow: hidden;
            font-size: 30px;
            font-weight: bold;
            color: #1A1A1A;
          }
          .voucher-logo {
            height: 80px;
            width: 80px;
            background: no-repeat center;
            background-size: contain;
          }
        }
      }
    }
    .gift {
      height: 200px;
      margin-bottom: 15px;
      border-radius: 0;
    }
    .input-box {
      padding: 10px;
      width: 100%;
      border: 3px solid #F29700;
      .iconfont {
        padding-right: 25px;
        color: #FEAB22;
        font-size: 44px;
      }
      input {
        font-size: 32px;
        height: 50px;
        &[type='checkbox'] {
          margin-right: 10px;
        }
      }
    }
  }
</style>
