export default [
  {
    type: '2',
    name: '待领取',
    class: 'receive',
    bgUrl: require('../images/receive.svg')
  },
  {
    type: '3',
    name: '待发货',
    class: 'send',
    bgUrl: require('../images/send.svg')
  },
  {
    type: '4',
    name: '待收货',
    class: 'take',
    bgUrl: require('../images/take.svg')
  }
];
