<template>
  <div class="hunan">
    <router-view></router-view>
    <bottom-nav/>
  </div>
</template>

<script>
import bottomNav from '../common/bottom-nav';

export default {
  name: 'HuNan',
  components: {
    bottomNav
  },
  created() {}
};
</script>

<style scoped lang="scss">
  .hunan {
    min-height: 100%;
    padding-bottom: 120px;
    background: rgba(0, 0, 0, .1);
  }
</style>
