<template>
  <div class="active">
    <div class="title">活动专区</div>
    <div class="active-img"></div>
  </div>
</template>

<script>
export default {
  name: 'Active',
  data() {
    return {};
  },
  created() {}
};
</script>
<style scoped lang="scss">
  .active {
    background-color: #fff;
    .title {
      padding: 50px 0;
      font-size: 36px;
      text-align: center;
      position: relative;
      &:before {
        content: '';
        position: absolute;
        bottom: 30px;
        left: 50%;
        transform: translate(-50%, 0);
        height: 4px;
        width: 40px;
        background-color: #FEAB22;
      }
    }
    .active-img {
      height: 240px;
      background-color: red;
    }
  }
</style>
