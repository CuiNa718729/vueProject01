export default [
  {
    url: '/popular-activity',
    icon: 'icon-integral',
    name: '我的和币'
  },
  {
    url: '/integral-mall',
    icon: 'icon-order',
    name: '我的订单'
  },
  {
    url: '/personal-center',
    icon: 'icon-question',
    name: '积分规则'
  }
];
