<template>
  <div class="integral-mall">
    <div class="banner"></div>
    <section
      class="user-message"
      flex="dir:left cross:center main:justify">
      <div
        v-for="item in navList"
        :key="item.name">
        <div
          class="iconfont"
          :class="[item.icon]"></div>
        <p class="name">{{ item.name }}</p>
      </div>
    </section>
    <active></active>
    <change></change>
  </div>
</template>

<script>
import navList from './config/nav-list';
import active from './active';
import change from './change';

export default {
  name: 'IntegralMall',
  components: {
    active,
    change
  },
  data() {
    return {
      navList: navList
    };
  }
};
</script>
<style scoped lang="scss">
  .integral-mall {
    .banner {
      height: 400px;
      background-color: red;
    }
    .user-message {
      padding: 0 80px;
      margin-bottom: 30px;
      background: #fff;
      height: 200px;
      &>div {
        text-align: center;
      }
      .iconfont {
        background: #E1B96C;
        border-radius: 50%;
        height: 80px;
        width: 80px;
        margin: 0 auto 10px;
        font-size: 36px;
        line-height: 80px;
        color: #fff;
      }
    }
  }
</style>
