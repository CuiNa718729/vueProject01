<template>
  <div class="change">
    <div class="title">兑换专区</div>
    <section class="list-box clearfix">
      <div
        v-for="item in list"
        :key="item.name"
        flex="dir:left main:justify"
        class="list">
        <div
          class="list-explain"
          flex="dir:top main:justify"
          flex-box="1">
          <p class="name">{{ item.name }}</p>
          <p class="gold">{{ item.gold }}  和币</p>
          <div class="btn"><span>兑换</span></div>
        </div>
        <div
          class="list-img"
          flex-box="0"></div>
      </div>
    </section>
  </div>
</template>

<script>
export default {
  name: 'Change',
  data() {
    return {
      list: [
        {
          name: '智能电视机',
          gold: 40000
        },
        {
          name: '王者荣耀游戏手柄',
          gold: 2000
        },
        {
          name: '电话手表一对',
          gold: 500
        },
      ]
    };
  },
  created() {}
};
</script>
<style scoped lang="scss">
  .change {
    background-color: #fff;
    .title {
      padding: 50px 0;
      font-size: 36px;
      text-align: center;
      position: relative;
      &:before {
        content: '';
        position: absolute;
        bottom: 30px;
        left: 50%;
        transform: translate(-50%, 0);
        height: 4px;
        width: 40px;
        background-color: #FEAB22;
      }
    }
    .list-box {
      .list {
        float: left;
        margin-right: 4%;
        margin-top: 30px;
        padding: 30px;
        width: 48%;
        height: 200px;
        background: #FEAB22;
        &:nth-child(1), &:nth-child(2) {
          margin-top: 0;
        }
        &:nth-child(2n) {
          margin-right: 0;
        }
        .list-explain {
          color: #1A1A1A;
          .name {
            width: 180px;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
            font-size: 32px;
          }
          .gold {
            font-size: 26px;
          }
          .btn>span {
            display: inline-block;
            padding: 0 25px;
            border-radius: 18px;
            line-height: 40px;
            font-size: 24px;
            background-color: #fff;
          }
        }
        .list-img {
          width: 100px;
          height: 120px;
          background-color: blue;
        }
      }
    }
  }
</style>
