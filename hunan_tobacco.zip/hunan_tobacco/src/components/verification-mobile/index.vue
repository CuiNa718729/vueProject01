<template>
  <div
    class="verification-mobile"
    flex="dir:top cross:center main:center">
    <img
      class="logo"
      :src="logo"
      flex-box="0"
      alt="logo">
    <p class="explain">吸烟有害健康 尽早戒烟有益健康</p>
    <p
      class="info"
      flex="dir:left cross:center">
      <span class="iconfont icon-tips"></span>
      <span>本页包含烟草产品信息，未满18岁请勿继续访问</span>
    </p>
    <section class="form">
      <div
        class="input-box"
        flex="dir:left cross:bottom main:justify">
        <div
          class="icon phone"
          flex-box="0"></div>
        <input
          v-model="mobile"
          type="tel"
          flex-box="1"
          maxlength="11"
          placeholder="请您输入您的手机号">
      </div>
      <div
        class="input-box"
        flex="dir:left cross:bottom main:justify">
        <div
          class="icon lock"
          flex-box="0"></div>
        <input
          v-model="vcode"
          type="tel"
          flex-box="1"
          maxlength="4"
          placeholder="请输入验证码">
        <div
          v-if="checkScan === 1"
          class="iconfont icon-select"
          flex-box="0"></div>
        <div
          v-if="checkScan === 0"
          class="iconfont icon-wrong"
          flex-box="0"></div>
        <div
          class="btn"
          :class="{disable: countdownTime > 0 || loadingScan}"
          flex-box="0"
          @click="sendVCode">
          <span>点击获取</span>
          <span v-if="countdownTime > 0">{{ countdownTime }}</span>
          <span
            v-if="loadingScan"
            class="iconfont icon-loading"></span>
        </div>
      </div>
      <div
        class="input-box"
        flex="dir:left cross:bottom main:justify">
        <div
          class="icon seal"
          flex-box="0"></div>
        <input
          v-model="token"
          type="text"
          flex-box="1"
          placeholder="输入私人印鉴">
      </div>
      <div
        class="input-box no-border"
        flex="dir:left cross:center">
        <input
          v-model="agree"
          id="agreement"
          type="checkbox"
          flex-box="0">
        <label
          class="agreement"
          for="agreement">
          <span>我已悉知以上提更换手机号示信息并年满18岁,并同意</span>
          <a href="">用户协议</a>
        </label>
      </div>
    </section>
    <div
      :class="{already: alreadySubmit}"
      class="submit-btn"
      @click="verify">验证手机</div>
  </div>
</template>

<script>

export default {
  name: 'VerificationMobile',
  components: {},
  data() {
    return {
      mobile: '',
      vcode: '',
      token: '',
      agree: '',
      logo: require('./images/logo.png'),
      countdownTime: 0,
      setTime: null,
      checkScan: '',
      loadingScan: false
    };
  },
  computed: {
    userInfo() {
      return this.$store.state.user;
    },
    alreadySubmit() {
      return (this.mobile && this.vcode && this.agree && this.checkScan === 1);
    }
  },
  watch: {
    countdownTime(val) {
      if (val === 0) clearInterval(this.setTime);
    },
    vcode(val) {
      if (val.length === 4) {
        this.checkScanNum(val);
      }
    }
  },
  methods: {
    async sendVCode() {
      if (!this.mobile) return;
      if (this.countdownTime > 0 || this.loadingScan) return;
      this.loadingScan = true;
      let result = await this.$http.post('/api/send_vcode', {
        mobile: this.mobile
      });
      this.loadingScan = false;
      if (result._http_status !== 200 || result.code !== 0) {
        this.$error({
          text: result.message
        });
        return;
      }
      this.countdownTime = 60;
      this.countdown();
    },
    async checkScanNum(val) {
      if (!this.mobile) return;
      let result = await this.$http.post('/api/verify_vcode', {
        mobile: this.mobile,
        vcode: val
      });
      (result._http_status !== 200 || result.code !== 0)
        ? this.checkScan = 0
        : this.checkScan = 1;
    },
    countdown() {
      this.setTime = setInterval(() => {
        this.countdownTime -= 1;
      }, 1000);
    },
    async verify() {
      // if (!this.alreadySubmit) return;
      let result = await this.$http.post('/api/bind_mobile', {
        mobile: this.mobile,
        vcode: this.vcode,
        token: this.token
      });
      if (result._http_status !== 200 || result.code !== 0) {
        this.$error({
          text: result.message
        });
        return;
      }
      this.$store.commit('CHANGE_USER_PARAMS', {
        phone: this.mobile,
        token: this.token
      });
      this.$router.push({ path: '/hunan' });
    }
  }
};
</script>
<style scoped lang="scss">
  .verification-mobile {
    min-height: 100%;
    padding: 20px 40px;
    background: #fff;
    .logo {
      width: 210px;
      margin-bottom: 40px;
    }
    .explain {
      margin-bottom: 10px;
      font-size: 32px;
      color: #666;
    }
    .info {
      margin-bottom: 40px;
      font-size: 24px;
      color: #999;
    }
    .icon-tips {
      margin-right: 15px;
      font-size: 46px;
      color: #FEAB22;
    }
    .form {
      margin-bottom: 60px;
      .input-box {
        width: 100%;
        height: 80px;
        margin-bottom: 30px;
        padding-bottom: 8px;
        border-bottom: 1px solid #ccc;
        .icon {
          margin-right: 25px;
          width: 40px;
          height: 40px;
          background: no-repeat center;
          background-size: contain;
        }
        .lock {
          background-image: url("./images/lock.svg");
        }
        .phone {
          background-image: url("./images/phone.svg");
        }
        .seal {
          background-image: url("./images/seal.svg");
        }
        &:last-child {
          margin-bottom: 0;
        }
        .btn {
          padding:0 15px;
          font-size: 26px;
          line-height: 50px;
          color: #fff;
          background-color: #FEAB22;
          border-radius: 6px;
          &.disable {
            background-color: #666;
          }
        }
        .seal-word {
          font-size: 32px;
        }
        .iconfont {
          padding-right: 25px;
          color: #FEAB22;
          font-size: 44px;
        }
        .icon-select {
          font-size: 30px;
          color: #58d03e;
          line-height: 50px;
        }
        .icon-wrong {
          font-size: 30px;
          color: #f11c1c;
          line-height: 50px;
        }
        @keyframes turn {
          from {
            transform: rotate(0deg);
          }
          to {
            transform: rotate(360deg);
          }
        }
        .icon-loading {
          display: inline-block;
          animation: turn 2s linear infinite;
          padding-right: 0;
          color: #fff;
          font-size: 24px;
          line-height: 50px;
        }
        input {
          font-size: 32px;
          height: 44px;
          &[type='checkbox'] {
            margin-right: 10px;
          }
        }
        .agreement {
          font-size: 24px;
          a {
            display: inline-block;
            color: #1482E6;
          }
        }
      }
      .no-border {
        border: none;
      }
    }
    .submit-btn {
      width: 100%;
      color: #fff;
      padding: 20px 0;
      background-color: #CCC;
      border-radius: 6px;
      text-align: center;
      font-size: 44px;
      &.already {
        background-color: #FEAB22;
      }
    }
  }
</style>
