<template>
  <div class="user">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'User',
  components: {},
  created() {}
};
</script>

<style scoped lang="scss">
  .user {
    height: 100%;
  }
</style>
