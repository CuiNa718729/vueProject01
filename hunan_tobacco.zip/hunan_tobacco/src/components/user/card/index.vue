<template>
  <div class="user-card">
    <div
      v-for="item in cardList"
      :key="item.ticketid"
      class="card-list"
      flex="dir:left">
      <div
        class="card-info"
        flex="dir:left cross:center"
        flex-box="1">
        <div
          class="logo"
          flex-box="0"
          :style="{backgroundImage: `url(${item.image})`}"></div>
        <div class="name">{{ item.title }}</div>
      </div>
      <div
        class="btn"
        flex="cross:center main:center"
        flex-box="0">
        <span>使用</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'UserCard',
  components: {},
  data() {
    return {
      cardList: []
    };
  },
  async mounted() {
    let result = await this.$http.post('/api/user_tickets');
    if (result._http_status !== 200 || result.code !== 0) {
      this.$error({
        text: result.message
      });
      return;
    }
    this.cardList = result.data || {};
  }
};
</script>

<style scoped lang="scss">
  .user-card {
    padding: 30px 20px;
    min-height: 100%;
    background-color: #eee;
    .card-list {
      margin-bottom: 20px;
      border-radius: 10px;
      overflow: hidden;
      &:last-child {
        margin-bottom: 0;
      }
      .card-info {
        background-color: #fff;
        padding: 0 40px;
        .logo {
          margin-right: 20px;
          width: 110px;
          height: 110px;
          border-radius: 50%;
          background: no-repeat center;
          background-size: contain;
        }
        .name {
          font-size: 34px;
        }
      }
      .btn {
        width: 200px;
        height: 180px;
        background: radial-gradient(
            rgba(0, 0, 0, 0) 0px,
            rgba(0, 0, 0, 0) 16px,
            #FEA71A 16px
        ) no-repeat -50px -162px;
        background-size: 500px 500px;
        &>span {
          display: inline-block;
          padding: 0 30px;
          line-height: 50px;
          border-radius: 25px;
          background-color: rgba(0, 0, 0, .25);
          color: #fff;
        }
      }
    }
  }
</style>
