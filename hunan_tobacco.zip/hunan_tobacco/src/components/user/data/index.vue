<template>
  <div class="user-data">
    <div class="nav-list">
      <section class="user-nav user-photo">
        <div
          class="top"
          flex="dir:left cross:center main:justify">
          <p class="name">头像</p>
          <div
            class="arrow"
            flex="cross:center">
            <span
              class="photo"
              :style="{backgroundImage: `url(${userInfo.user_img})`}"></span>
            <span class="iconfont icon-arrow-right"></span>
          </div>
        </div>
      </section>
      <section class="user-nav">
        <div
          class="top"
          flex="dir:left cross:center main:justify"
          @click="addName">
          <p class="name">昵称</p>
          <div class="arrow">
            <span>{{ userInfo.user_name }}</span>
            <span class="iconfont icon-arrow-right"></span>
          </div>
        </div>
      </section>
      <section class="user-nav">
        <div
          class="top"
          flex="dir:left cross:center main:justify"
          @click="addSex">
          <p class="name">性别</p>
          <div class="arrow">
            <span>女</span>
            <span class="iconfont icon-arrow-right"></span>
          </div>
        </div>
      </section>
      <section class="user-nav">
        <div
          class="top"
          flex="dir:left cross:center main:justify"
          @click="addAge">
          <p class="name">年龄</p>
          <div class="arrow">
            <span class="iconfont icon-arrow-right"></span>
          </div>
        </div>
      </section>
      <section class="user-nav">
        <div
          class="top"
          flex="dir:left cross:center main:justify"
          @click="addToken">
          <p class="name">私人印鉴</p>
          <div class="arrow">
            <span v-if="userInfo.token">{{ userInfo.token }}</span>
            <span v-else>添加私人印鉴</span>
            <span class="iconfont icon-arrow-right"></span>
          </div>
        </div>
      </section>
      <section class="user-nav">
        <div
          class="top"
          flex="dir:left cross:center main:justify"
          @click="openSmoke = true">
          <p class="name">喜欢的烟</p>
          <div class="arrow">
            <span class="iconfont icon-arrow-right"></span>
          </div>
        </div>
      </section>
    </div>
    <section class="tobacco-list clearfix">
      <div
        v-for="item in favoriteList"
        :key="item.ticketid"
        class="kind">{{ item.name }}</div>
    </section>
    <confirm-box
      v-model="openToken"
      title="添加印鉴"
      @click-confirm="changeSeal">
      <div
        class="input-box"
        flex="dir:left cross:bottom main:justify">
        <div
          class="iconfont icon-seal"
          flex-box="0"></div>
        <input
          v-model="token"
          type="text"
          flex-box="1"
          placeholder="启用私人印鉴">
      </div>
    </confirm-box>
    <confirm-box
      v-model="openName"
      title="修改昵称"
      @click-confirm="changeName">
      <div
        class="input-box"
        flex="dir:left cross:bottom main:justify">
        <input
          v-model="name"
          type="text"
          flex-box="1"
          placeholder="您的姓名">
      </div>
    </confirm-box>
    <confirm-box
      v-model="openSex"
      title="修改性别"
      @click-confirm="changeSex">
      <div
        class="input-box no-border sex"
        flex="dir:left main:center">
        <label
          flex="dir:left cross:center"
          flex-box="0">
          <input
            type="radio"
            v-model="sex"
            value="man"/>
          <span>先生</span>
        </label>
        <label
          flex="dir:left cross:center"
          flex-box="0">
          <input
            type="radio"
            v-model="sex"
            value="woman"/>
          <span>女士</span>
        </label>
      </div>
    </confirm-box>
    <confirm-box
      v-model="openAge"
      title="修改年龄"
      @click-confirm="changeAge">
      <div
        class="input-box"
        flex="dir:left cross:bottom main:justify">
        <label>
          <select v-model="age">
            <option
              value=""
              disabled
              selected>请选择</option>
            <option value="1">1</option>
            <option value="2">2</option>
          </select>
        </label>
      </div>
    </confirm-box>
    <select-box
      v-model="openSmoke"
      title="喜欢的烟"
      :list="smokeList"
      @click-sure="changeSmoke"
      :default-list="selectList"></select-box>
  </div>
</template>

<script>
import confirmBox from '@/components/common/confirm';
import selectBox from '@/components/common/select';

export default {
  name: 'UserData',
  components: {
    confirmBox,
    selectBox
  },
  data() {
    return {
      openToken: false,
      openName: false,
      openSex: false,
      openAge: false,
      openSmoke: false,
      sex: '',
      age: '',
      name: '',
      token: '',
      selectList: [1],
      smokeList: [
        {
          id: 1,
          name: '白沙',
          color: '#387daf'
        },
        {
          id: 2,
          name: '黄鹤楼',
          color: '#d06938'
        },
        {
          id: 3,
          name: '白沙2',
          color: '#387daf'
        },
        {
          id: 4,
          name: '黄鹤楼2',
          color: '#d06938'
        },
        {
          id: 5,
          name: '白沙3',
          color: '#387daf'
        },
        {
          id: 6,
          name: '黄鹤楼3',
          color: '#d06938'
        }
      ],
      favoriteList: null
    };
  },
  computed: {
    userInfo() {
      return this.$store.state.user;
    }
  },
  created() {
    this.getSmokeList();
  },
  methods: {
    async getSmokeList() {
      let result = await this.$http.post('/api/user_favorate');
      if (result._http_status !== 200 || result.code !== 0) {
        this.$error({
          text: result.message
        });
        return;
      }
      this.favoriteList = result.data;
    },
    addToken() {
      if (this.userInfo.token) return;
      this.openToken = true;
    },
    addName() {
      this.openName = true;
    },
    addSex() {
      this.openSex = true;
    },
    addAge() {
      this.openAge = true;
    },
    async changeSeal() {
      if (this.token === '') {
        this.openToken = false;
        return;
      }
      let result = await this.$http.post('/api/update_token', {
        token: this.token
      });
      if (result._http_status === 200 && result.code === 0) {
        this.$store.commit('CHANGE_USER_PARAMS', {
          token: this.token
        });
      }
      this.openToken = false;
    },
    async changeName() {
      if (this.name === '') {
        this.openName = false;
        return;
      }
      let result = await this.$http.post('/api/update_user_info', {
        nickname: this.name
      });
      if (result._http_status === 200 && result.code === 0) {
        this.$store.commit('CHANGE_USER_PARAMS', {
          user_name: this.name
        });
      }
      this.name = '';
      this.openName = false;
    },
    async changeSex() {
      console.log(111);
    },
    async changeAge() {
      console.log(111);
    },
    changeSmoke(val) {
      console.log(val);
    }
  }
};
</script>

<style scoped lang="scss">
  .user-data {
    padding: 30px 0 0;
    min-height: 100%;
    background-color: #eee;
    .user-nav {
      background-color: #fff;
      padding-left: 25px;
      &.user-photo {
        .photo {
          display: inline-block;
          margin-right: 10px;
          height: 90px;
          width: 90px;
          border-radius: 50%;
          background: no-repeat center;
          background-size: cover;
        }
      }
      .top {
        padding: 30px 30px 30px 0;
        border-bottom: 1px solid #DBDBDB;
        font-size: 30px;
        color: #1A1A1A;
        .arrow {
          color: #CBCBCB;
        }
        .iconfont {
          font-weight: bold;
          font-size: 30px;
        }
      }
      &:last-child {
        .top {
          border-bottom: none;
        }
      }
    }
    .tobacco-list {
      padding: 40px;
      &>div {
        float: left;
        padding: 0 40px;
        line-height: 56px;
        margin-right: 30px;
        margin-bottom: 30px;
        border-radius: 28px;
        background-color: #F29B76;
        color: #fff;
        font-size: 30px;
      }
    }
    .input-box {
      padding: 10px;
      width: 100%;
      border: 3px solid #F29700;
      .iconfont {
        padding-right: 25px;
        color: #FEAB22;
        font-size: 44px;
      }
      input {
        font-size: 32px;
        height: 50px;
        &[type='checkbox'] {
          margin-right: 10px;
        }
      }
      label, select {
        font-size: 32px;
        height: 50px;
        width: 100%;
      }
      &.no-border {
        border: none;
      }
      &.sex {
        label {
          width: auto;
          padding: 0 40px;
          margin-right: 50px;
          &:last-child {
            margin-right: 0;
          }
          input {
            margin-right: 20px;
          }
        }
      }
    }
  }
</style>
