<template>
  <div class="product-details">
    <div class="goods-info">
      <div
        :style="{backgroundImage: `url(${goodsInfo.product_image})`}"
        class="goods"></div>
      <ul class="goods-details">
        <li>{{ goodsInfo.name }}</li>
        <li>生产商：<span>湖南中烟工业有限责任公司</span></li>
        <li>厂商官方客服电话：<em>400-8855788</em></li>
      </ul>
    </div>
    <div class="details-box">
      <div class="title">基本信息</div>
      <ul class="info-list">
        <li>类型：{{ goodsInfo.type_name }}</li>
        <li>烟支规格：{{ goodsInfo.spec }}mm</li>
        <li>焦油量：{{ goodsInfo.oil }}mg</li>
        <li>CO含量：{{ goodsInfo.carbon_monoxide }}mg</li>
        <li>烟气烟碱量：{{ goodsInfo.nicotine }}mg</li>
      </ul>
    </div>
    <div class="scan-box">
      <div class="title">扫码记录</div>
      <ul class="scan-list">
        <li
          v-for="(item, index) in scanInfo"
          :key="index">用户：<span>{{ item.user }}</span> <em>扫码：{{ item.count }}次</em></li>
      </ul>
    </div>
    <button
      class="feedback"
      @click="open = true">我要反馈</button>
    <confirm-box
      v-model="open"
      title="反馈信息"
      @click-confirm="feedbackSubmit">
      <div
        class="input-box"
        flex="dir:left cross:bottom main:justify">
        <textarea
          v-model="feedback"
          flex-box="1"
          rows="3"
          placeholder="请输入反馈信息"></textarea>
      </div>
    </confirm-box>
  </div>
</template>

<script>
import confirmBox from '@/components/common/confirm';

export default {
  name: 'ProductDetails',
  components: {
    confirmBox
  },
  data() {
    return {
      scanInfo: {},
      open: false,
      feedback: '',
      goodsInfo: {}
    };
  },
  created() {},
  mounted() {
    this.$http.post('/api/product_info').then(res => {
      if (res._http_status !== 200 || res.code !== 0) return;
      this.goodsInfo = res.data;
    });
    this.$http.post('/api/scan_history').then(res => {
      this.scanInfo = res.data;
    });
  },
  methods: {
    feedbackSubmit() {}
  }
};
</script>

<style scoped lang="scss">
  .product-details {
    padding: 25px 30px 140px;
    min-height: 100%;
    background-color: #eee;
    .goods-info {
      overflow: hidden;
      margin: 65px 0 69px;
      .goods {
        float: left;
        width: 75px;
        height: 150px;
        margin: 0 59px 0 48px;
        background-color: #333;
        background: no-repeat 50%;
        background-size: contain;
      }
    }
    .goods-details {
      float: left;
      font-size: 28px;
      li {
        color: #1A1A1A;
        margin-bottom: 15px;
        &:first-child {
          color: #39A2E2;
          margin-bottom: 25px;
        }
        span {
          font-weight: 200;
        }
        em {
          color: #FEAB22;
        }
      }
    }
    .details-box, .scan-box {
      background-color: #fff;
      padding: 0 30px;
      margin-bottom: 21px;
      .title {
        font-size: 30px;
        color: #000;
        padding: 30px 0 25px;
        border-bottom: 1px solid #eee;
      }
      .info-list {
        padding: 20px 0;
        color: #7C7C7C;
        font-size: 28px;
        line-height: 48px;
      }
    }
    .scan-box {
      .scan-list {
        color: #565656;
        font-size: 26px;
        position: relative;
        padding: 20px 0;
        &:after {
          position: absolute;
          display: block;
          content: '';
          top: 50%;
          left: 10px;
          transform: translate(0 ,-50%);
          width: 1px;
          height: 60%;
          background-color: #FEA71A;
        }
        li {
          line-height: 70px;
          padding-left: 44px;
          position: relative;
          &:after {
            position: absolute;
            z-index: 10;
            display: block;
            content: '';
            left: 0;
            top: 50%;
            transform: translate(0 ,-50%);
            width: 20px;
            height: 20px;
            border: 1px solid #FEA71A;
            border-radius: 50%;
            background-color: #fff;
          }
          em {
            float: right;
          }
        }
      }
    }
    .feedback {
      position: fixed;
      z-index: 100;
      bottom: 0;
      left: 0;
      width: 100%;
      line-height: 115px;
      font-size: 38px;
      background-color: #FEAB22;
      color: #fff;
    }
    .input-box {
      padding: 10px;
      width: 100%;
      border: 3px solid #F29700;
      textarea {
        font-size: 32px;
        min-height: 150px;
      }
    }
  }
</style>
