<template>
  <div class="user-exp">
    <div class="head">
      <div
        class="messsage"
        flex="dir:top main:justify">
        <div class="logo iconfont icon-integral"></div>
        <p class="exp">经验值: {{ userInfo.xp }}</p>
        <p class="explain">我的经验值</p>
      </div>
    </div>
    <div class="list-box">
      <div
        v-for="item in expList"
        :key="item.name"
        flex="dir:left cross:center main:justify"
        class="list">
        <div class="list-msg">
          <p class="name">{{ item.title }}</p>
          <p class="time">{{ item.time }}</p>
        </div>
        <div class="list-gold">+ {{ item.amount }}</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'UserExp',
  components: {},
  data() {
    return {
      expList: []
    };
  },
  computed: {
    userInfo() {
      return this.$store.state.user;
    }
  },
  async mounted() {
    let result = await this.$http.post('/api/empirical_value_history');
    if (result._http_status !== 200 || result.code !== 0) {
      this.$error({
        text: result.message
      });
      return;
    }
    this.expList = result.data || {};
  }
};
</script>
<style scoped lang="scss">
  .user-exp {
    .head {
      padding-top: 50px;
      height: 500px;
      background-color: #FEAB22;
      .messsage {
        position: relative;
        z-index: 10;
        height: 450px;
        padding: 0 40px;
        border-top-left-radius: 30px;
        border-top-right-radius: 30px;
        text-align: center;
        background-color: #fff;
        &:after {
          position: absolute;
          top: -25px;
          left: 50%;
          transform: translate(-50%, 0);
          content: '';
          width: 170px;
          height: 170px;
          border-radius: 50%;
          background-color: #fff;
          z-index: -1;
        }
        .logo {
          width: 90px;
          margin: 20px auto 0;
          border-radius: 50%;
          line-height: 90px;
          font-size: 50px;
          color: #fff;
          background-color: #FEAB22;
        }
        .exp {
          padding-bottom: 40px;
          font-weight: bold;
          font-size: 40px;
          color: #1A1A1A;
        }
        .explain {
          padding-bottom: 40px;
          text-align: left;
          font-weight: bold;
          font-size: 30px;
          color: #333;
        }
      }
    }
    .list-box {
      padding: 0 40px;
      .list {
        padding: 30px 0;
        border-top: 1px solid #eee;
        .list-msg {
          .name {
            width: 500px;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
            margin-bottom: 15px;
            color: #505050;
            font-size: 30px;
          }
          .time {
            color: #999;
            font-size: 24px;
          }
        }
        .list-gold {
          color: #333333;
          font-size: 36px;
        }
        &:last-child {
          border-bottom: 1px solid #eee;
        }
      }
    }
  }
</style>
