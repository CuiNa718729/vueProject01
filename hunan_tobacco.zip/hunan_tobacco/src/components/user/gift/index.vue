<template>
  <div class="user-gift">
    <section
      class="tab"
      flex="dir:left main:justify box:mean">
      <div
        v-for="item in tabList"
        :key="item.type"
        :class="{active: tabSelect === item.type}"
        @click="chooseTabType(item.type)">{{ item.name }}</div>
    </section>
    <section class="gift-list">
      <div
        v-for="(item, index) in giftList"
        :key="index"
        class="gift-box">
        <div
          class="gift-msg"
          flex="dir:left">
          <div
            class="logo"
            flex-box="0"
            :style="{backgroundImage: `url(${item.image})`}"></div>
          <div
            class="explain"
            flex="dir:top main:center"
            flex-box="1">
            <p class="name">{{ item.title }}</p>
            <p
              v-if="tabSelect === '2'"
              class="time">{{ item.message }}</p>
          </div>
          <div
            class="num"
            flex="cross:center"
            flex-box="0">x {{ item.amount }}</div>
        </div>
        <div
          class="gift-time"
          flex="dir:left cross:center">
          <div
            class="time"
            flex-box="1">
            <p>中奖时间：{{ item.win_time }}</p>
            <p v-if="tabSelect === '1'">领取时间：{{ item.get_time }}</p>
            <p v-if="tabSelect === '2'">逾期时间：{{ item.expire_time }}</p>
            <p v-if="tabSelect === '4'">发货时间：{{ item.sent_time }}</p>
          </div>
          <div
            v-if="tabSelect !== '1'"
            class="btn"
            flex-box="0"
            @click="getGift(item.prizeid)">{{ tabSelect | showSelectWord }}</div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
import tabList from './config/tab-list';

export default {
  name: 'UserGift',
  filters: {
    showSelectWord(val) {
      if (val === '2') return '领取';
      if (val === '3') return '查看收货地址';
      if (val === '4') return '确认收货';
      return '';
    }
  },
  data() {
    return {
      tabSelect: '',
      tabList: tabList,
      giftList: []
    };
  },
  computed: {
    showTabNum() {
      let { type } = this.$route.query;
      if (!type) return false;
      return String(type);
    }
  },
  watch: {
    tabSelect(val) {
      this.getList(val);
    }
  },
  mounted() {
    this.tabSelect = this.showTabNum || '1';
  },
  methods: {
    async getList(val) {
      let result = await this.$http.post('/api/user_prize_list', {
        type: val
      });
      if (result._http_status !== 200 || result.code !== 0) {
        this.$error({
          text: result.message
        });
        return;
      }
      this.giftList = result.data || {};
    },
    chooseTabType(type) {
      this.tabSelect = type;
    },
    async getGift(id) {
      if (this.tabSelect === '2') {
        let result = await this.$http.post('/api/get_prize', {
          prize_id_list: id
        });
        if (result._http_status === 200 && result.code === 0) {
          this.getList();
        }
        this.$error({
          text: result.message
        });
      }
      if (this.tabSelect === '3') {
        this.$router.push({ path: '/user/take-gift', query: { id: id } });
      }
      // if (this.tabSelect === '4') {}
    }
  }
};
</script>
<style scoped lang="scss">
  .user-gift {
    min-height: 100%;
    background-color: #eee;
    .tab {
      padding: 30px 30px;
      font-size: 24px;
      background-color: #fff;
      color: #666;
      &>div {
        padding: 15px 0;
        text-align: center;
        border-top: 1px solid #FEAB22;
        border-bottom: 1px solid #FEAB22;
        &:first-child {
          border-left: 1px solid #FEAB22;
          border-top-left-radius: 8px;
          border-bottom-left-radius: 8px;
        }
        &:last-child {
          border-right: 1px solid #FEAB22;
          border-top-right-radius: 8px;
          border-bottom-right-radius: 8px;
        }
      }
      .active {
        background-color: #FEAB22;
        color: #fff;
      }
    }
    .gift-list {
      .gift-box {
        margin-top: 20px;
        padding: 40px 0 40px 40px;
        background-color: #fff;
        .gift-msg {
          padding-right: 40px;
          padding-bottom: 20px;
          border-bottom: 1px solid #eee;
          .logo {
            height: 110px;
            width: 80px;
            background: no-repeat center;
            background-size: contain;
          }
          .explain {
            padding: 10px 20px 10px 50px;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
            .name {
              color: #1A1A1A;
              font-size: 30px;
            }
            .time {
              margin-top: 5px;
              color: #E4603D;
              font-size: 26px;
            }
          }
          .num {
            color: #666;
            font-size: 26px;
          }
        }
        .gift-time {
          margin-top: 40px;
          padding-right: 40px;
          .time {
            color: #333333;
            font-size: 26px;
            padding-right: 40px;
            p {
              margin-bottom: 15px;
              &:last-child {
                margin-bottom: 0;
              }
            }
          }
          .btn {
            padding: 10px 45px;
            color: #F79E1B;
            border: 1px solid #F79E1B;
            border-radius: 8px;
          }
        }
      }
    }
  }
</style>
