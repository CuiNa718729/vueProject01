<template>
  <div class="user-take-gift">
    <section
      class="user-address"
      flex="dir:left"
      @click="changeAddress">
      <div
        v-if="address"
        class="user-info"
        flex-box="1">
        <div class="name-mobile">
          <span>{{ address.recipient }}</span>
          <span>{{ address.mobile }}</span>
        </div>
        <p class="area">{{ userAddress }}</p>
      </div>
      <div
        v-else
        class="user-info add"
        flex="cross:center"
        flex-box="1">新增收货地址</div>
      <div
        class="arrow"
        flex="cross:center main:center"
        flex-box="0">
        <span class="iconfont icon-arrow-right"></span>
      </div>
    </section>
    <div class="warn">
      <p>尊敬的用户：</p>
      <p>我们严格保护您的个人信息安全，我们收集和使用
      您的收货地址相关信息，仅用于完成您的个人订单
      交易，不作为其他的用途</p>
    </div>
    <section class="gift-box">
      <div
        v-for="(item, index) in giftList"
        :key="index"
        class="gift-info"
        flex="dir:left">
        <div
          class="logo"
          flex-box="0"
          :style="{backgroundImage: `url(${item.img_url})`}"></div>
        <div
          class="explain"
          flex="dir:top main:justify"
          flex-box="1">
          <p class="name">{{ item.award_name }}</p>
          <p class="money">{{ item.expire_time_message }}</p>
        </div>
        <div
          class="num"
          flex="cross:center"
          flex-box="0">x {{ item.amount }}</div>
      </div>
    </section>
    <div
      class="btn"
      :class="{'agreeSubmit': agreeSubmit}"
      @click="makeSure">确认领取</div>
  </div>
</template>

<script>
export default {
  name: 'UserTakeGift',
  components: {},
  data() {
    return {
      giftList: [],
      address: null
    };
  },
  computed: {
    idList() {
      let { id } = this.$route.query;
      if (id) return id.split('|');
      return [];
    },
    userAddress() {
      let {
        provinceName,
        cityName,
        districtName,
        address
      } = this.address;
      return `${provinceName}${cityName}${districtName}${address}`;
    },
    agreeSubmit() {
      return this.address && this.address.addressId && this.idList.length > 0;
    }
  },
  async created() {
    let result = await this.$http.post('/api/query_prize_address', {
      prize_id_list: this.idList
    });
    if (result._http_status !== 200 || result.code !== 0) {
      this.$error({
        text: result.message
      });
      return;
    }
    this.address = result.data.address;
    this.giftList = result.data.prize;
  },
  methods: {
    changeAddress() {
      if (this.address) {
        this.$router.push({ path: '/user/address', query: { take: 1 } });
      } else {
        this.$router.push('/user/change-address');
      }
    },
    async makeSure() {
      if (!this.agreeSubmit) return;
      let result = await this.$http.post('/api/get_prize', {
        address_id: this.address.addressId,
        prize_id_list: this.idList,
      });
      this.$error({
        text: result.message
      });
      if (result._http_status !== 200 || result.code !== 0) return;
      this.$router.go(-1);
    }
  }
};
</script>

<style scoped lang="scss">
  .user-take-gift {
    padding: 30px 0 120px;
    min-height: 100%;
    background-color: #eee;
    .user-address {
      padding: 40px 0 40px 40px;
      background-color: #fff;
      position: relative;
      &:after {
        position: absolute;
        content: '';
        top: -6px;
        left: 0;
        width: 100%;
        height: 6px;
        background: repeating-linear-gradient(
            -45deg,
            #fff, #fff 20px,
            #1A1A1A 20px, #1A1A1A 40px,
            #fff 40px, #fff 60px,
            #FDCB45 60px, #FDCB45 80px
        );
      }
      .user-info {
        padding-right: 30px;
        &.add {
          color: #333;
          font-size: 36px;
        }
        .name-mobile {
          color: #333;
          font-size: 30px;
          span:first-child {
            margin-right: 10px;
          }
        }
        .area {
          margin-top: 20px;
          color: #666;
          font-size: 26px;
        }
      }
      .arrow {
        padding: 0 30px;
        .iconfont {
          font-size: 40px;
          color: #ccc;
        }
      }
    }
    .gift-box {
      .gift-info {
        padding: 40px;
        margin-bottom: 20px;
        background-color: #fff;
        &:last-child {
          margin-bottom: 0;
        }
        .logo {
          height: 150px;
          width: 150px;
          background: no-repeat center;
          background-size: contain;
        }
        .explain {
          padding: 10px 20px 10px 50px;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
          .name {
            color: #1A1A1A;
            font-size: 30px;
          }
          .money {
            color: #C8A985;
            font-size: 26px;
          }
        }
        .num {
          color: #666;
          font-size: 26px;
        }
      }
    }
    .warn {
      padding: 40px;
      color: #999;
      font-size: 30px;
    }
    .btn {
      position: fixed;
      left: 50%;
      bottom: 10px;
      transform: translate(-50%, 0);
      width: 95%;
      border-radius: 10px;
      line-height: 100px;
      text-align: center;
      font-size: 44px;
      background-color: #ccc;
      color: #fff;
      &.agreeSubmit {
        background-color: #FEA71A;
      }
    }
  }
</style>
