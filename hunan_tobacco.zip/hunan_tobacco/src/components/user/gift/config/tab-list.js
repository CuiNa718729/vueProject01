export default [
  {
    type: '1',
    name: '已领取'
  },
  {
    type: '2',
    name: '待领取'
  },
  {
    type: '3',
    name: '待发货'
  },
  {
    type: '4',
    name: '待收货'
  }
];
