<template>
  <div class="user-advert">
    <div
      class="show-advert"
      :style="{backgroundImage: `url(${advertMsg.img})`}"></div>
    <div
      class="iconfont icon-close"
      @click="skip"></div>
    <div
      class="btn"
      @click="skip">
      <span>点击跳过</span>
      <span class="num">{{ timeNUm }}</span>
    </div>
  </div>
</template>

<script>
export default {
  name: 'UserAdvert',
  components: {},
  data() {
    return {
      time: null,
      timeNUm: 3
    };
  },
  computed: {
    advertMsg() {
      return this.$store.state.advert;
    }
  },
  watch: {
    timeNUm(val) {
      if (val === 0) {
        clearInterval(this.time);
        this.$router.replace('/hunan');
      }
    }
  },
  created() {
    this.time = setInterval(() => {
      this.timeNUm -= 1;
    }, 1000);
  },
  methods: {
    skip() {
      clearInterval(this.time);
      this.$router.replace('/hunan');
    }
  }
};
</script>

<style scoped lang="scss">
  .user-advert {
    position: relative;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, .4);
    .show-advert {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 90%;
      height: 75%;
      background: no-repeat center;
      background-size: contain;
    }
    .icon-close {
      position: absolute;
      bottom: 5%;
      left: 50%;
      transform: translate(-50%, 0);
      font-size: 56px;
      color: #fff;
    }
    .btn {
      position: absolute;
      top: 4%;
      right: 4%;
      line-height: 52px;
      border-radius: 26px;
      width: 210px;
      text-align: center;
      color: #fff;
      background-color: rgba(255, 255, 255, .3);
      .num {
        color: #FD2C00;
      }
    }
  }
</style>
