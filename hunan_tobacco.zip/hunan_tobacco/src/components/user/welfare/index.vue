<template>
  <div class="user-welfare">
    <div class="welfare-list">
      <p class="name">和+商城卡劵</p>
      <p class="money">100元抵用卷</p>
      <div class="logo"></div>
      <div class="btn">立即领取</div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'UserWelfare',
  components: {},
  created() {}
};
</script>

<style scoped lang="scss">
  .user-welfare {
    padding-top: 30px;
    min-height: 100%;
    .welfare-list {
      margin-bottom: 30px;
      background-color: #fff;
      &:last-child {
        margin-bottom: 0;
      }
    }
  }
</style>
