<template>
  <div class="user-address">
    <section class="address-list">
      <div
        v-for="item in addressList"
        :key="item.addressId"
        class="address-box">
        <div class="user">
          <span>{{ item.recipient }}</span>
          <span>{{ item.mobile }}</span>
        </div>
        <p class="info">{{ item.provinceName }}{{ item.cityName }}{{ item.districtName }} {{ item.address }}</p>
        <div
          class="select"
          flex="dir:left cross:center main:justify">
          <div
            class="default"
            flex="dir:left cross:center">
            <span
              class="iconfont icon-select"
              :class="{'default-address': item.type === 1}"></span>
            <span
              v-if="item.type === 0"
              @click="changeDefaultAddress(item.addressId)">设为收货地址</span>
            <span v-else>收货地址</span>
          </div>
          <div
            class="control"
            flex="dir:left cross:center">
            <div>
              <span class="iconfont icon-edit"></span>
              <span @click="changeAddress(item.addressId)">编辑</span>
            </div>
            <div>
              <span class="iconfont icon-delete"></span>
              <span @click="deleteAddress(item.addressId)">删除</span>
            </div>
          </div>
        </div>
      </div>
    </section>
    <div class="warn">
      <p>尊敬的用户：</p>
      <p>我们严格保护您的个人信息安全，我们收集和使用
      您的收货地址相关信息，仅用于完成您的个人订单
      交易，不作为其他的用途</p>
    </div>
    <router-link
      tag="div"
      to="/user/change-address"
      class="btn">+ 新建地址</router-link>
  </div>
</template>

<script>
export default {
  name: 'UserAddress',
  components: {},
  data() {
    return {
      addressList: []
    };
  },
  computed: {
    userInfo() {
      return this.$store.state.user;
    }
  },
  mounted() {
    this.getAddressList();
  },
  methods: {
    async getAddressList() {
      let result = await this.$http.post('/api/address_list');
      if (result._http_status !== 200 || result.code !== 0) {
        this.$error({
          text: result.message
        });
        return;
      }
      this.addressList = result.data || {};
    },
    changeDefaultAddress(id) {
      this.$http.post('/api/set_default_address', {
        address_id: id
      }).then(res => {
        this.$error({
          text: res.message,
          cancel: () => {
            if (res._http_status !== 200 || res.code !== 0) return;
            if (String(this.$route.query.take) === '1') this.$router.go(-1);
          }
        });
        if (res._http_status !== 200 || res.code !== 0) return;
        this.getAddressList();
      });
    },
    changeAddress(id) {
      this.$router.push({
        path: '/user/change-address',
        query: {
          id: id
        }
      });
    },
    deleteAddress(id) {
      this.$confirm({
        title: '确认删除？'
      }, async () => {
        let result = await this.$http.post('/api/delete_address', {
          address_id: id
        });
        if (result._http_status !== 200 || result.code !== 0) {
          this.$error({
            text: result.message
          });
        }
        await this.getAddressList();
      });
    }
  }
};
</script>

<style scoped lang="scss">
  .user-address {
    padding: 30px 0 120px;
    min-height: 100%;
    background-color: #eee;
    .address-list {
      .address-box {
        margin-bottom: 15px;
        padding: 40px;
        background-color: #fff;
        &:last-child {
          margin-bottom: 0;
        }
        .user {
          color: #333;
          font-size: 30px;
          span:first-child {
            margin-right: 10px;
          }
        }
        .info {
          margin-top: 20px;
          min-height: 80px;
          color: #666;
          font-size: 26px;
        }
        .select {
          margin-top: 20px;
          padding-top: 25px;
          border-top: 1px solid #eee;
          font-size: 24px;
          .default {
            .icon-select {
              margin-right: 10px;
              font-size: 30px;
              &.default-address {
                color: #FEA71A;
              }
            }
          }
          .control {
            &>div:first-child {
              margin-right: 15px;
            }
            .iconfont {
              font-size: 30px;
            }
          }
        }
      }
    }
    .warn {
      padding: 40px;
      color: #999;
      font-size: 30px;
    }
    .btn {
      position: fixed;
      left: 50%;
      bottom: 10px;
      transform: translate(-50%, 0);
      width: 95%;
      border-radius: 10px;
      line-height: 100px;
      text-align: center;
      font-size: 44px;
      background-color: #FEA71A;
      color: #fff;
    }
  }
</style>
