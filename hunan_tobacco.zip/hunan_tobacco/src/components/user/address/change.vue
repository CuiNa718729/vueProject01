<template>
  <div class="user-change-address">
    <p class="title">联系人</p>
    <section class="user-info">
      <div
        class="name"
        flex="dir:left cross:center">
        <p>收件人：</p>
        <label flex-box="1">
          <input
            v-model="name"
            type="text">
        </label>
      </div>
      <div
        class="mobile"
        flex="dir:left cross:center">
        <p>手机号：</p>
        <label flex-box="1">
          <input
            v-model="mobile"
            type="tel"
            maxlength="11">
        </label>
      </div>
    </section>
    <p class="title">收货地址</p>
    <section class="user-address">
      <div
        class="explain"
        flex="dir:left cross:center box:mean">
        <label>
          <select v-model="province">
            <option
              value=""
              disabled
              selected>省
            </option>
            <option
              v-for="item in provinceList"
              :key="item.code"
              :value="item.code">{{ item.name }}
            </option>
          </select>
        </label>
        <span flex-box="0">/</span>
        <label>
          <select v-model="city">
            <option
              value=""
              disabled
              selected>市
            </option>
            <option
              v-for="item in cityList"
              :key="item.code"
              :value="item.code">{{ item.name }}
            </option>
          </select>
        </label>
        <span flex-box="0">/</span>
        <label>
          <select v-model="district">
            <option
              value=""
              disabled
              selected>区
            </option>
            <option
              v-for="item in districtList"
              :key="item.code"
              :value="item.code">{{ item.name }}
            </option>
          </select>
        </label>
      </div>
      <div
        class="explain"
        flex="dir:left cross:center">
        <p>详细：</p>
        <label flex-box="1">
          <input
            v-model="address"
            type="text">
        </label>
      </div>
    </section>
    <div class="warn">
      <p>尊敬的用户：</p>
      <p>我们严格保护您的个人信息安全，我们收集和使用
      您的收货地址相关信息，仅用于完成您的个人订单
      交易，不作为其他的用途</p>
    </div>
    <div
      class="btn"
      :class="{'allow-submit':allowSubmit}"
      @click="chooseFun">确认地址</div>
  </div>
</template>

<script>
export default {
  name: 'UserChangeAddress',
  components: {},
  data() {
    return {
      init: true,
      name: '',
      mobile: '',
      provinceList: [],
      province: '',
      cityList: [],
      city: '',
      districtList: [],
      district: '',
      address: '',
    };
  },
  computed: {
    allowSubmit() {
      return this.name && this.mobile && this.address && this.province && this.city && this.district;
    },
    id() {
      return this.$route.query.id;
    }
  },
  watch: {
    province(value) {
      if (this.id && this.init) {
        this.getCity(value);
        return;
      }
      this.city = '';
      this.district = '';
      this.districtList = [];
      this.getCity(value);
    },
    city(value) {
      if (this.id && this.init) {
        this.init = false;
        this.getDistrict(value);
        return;
      }
      this.district = '';
      if (!value) return;
      this.getDistrict(value);
    }
  },
  async created() {
    await this.getProvince();
    if (!this.id) return;
    this.getAddress();
  },
  methods: {
    getAddress() {
      this.$http.post('/api/get_one_address', {
        address_id: this.id
      }).then(res => {
        if (res._http_status !== 200 || res.code !== 0) {
          this.$error({
            text: res.message
          });
          return;
        }
        this.name = res.data.recipient;
        this.mobile = res.data.mobile;
        this.province = parseInt(res.data.province);
        this.city = parseInt(res.data.city);
        this.district = parseInt(res.data.district);
        this.address = res.data.address;
      });
    },
    chooseFun() {
      if (!this.allowSubmit) return;
      if (!this.checkmobile()) return;
      if (this.id) {
        this.changeAddress();
      } else {
        this.createdAddress();
      }
    },
    checkmobile() {
      if (!/^[0-9]+$/.test(this.mobile) || this.mobile.length < 8) {
        this.$error({
          text: '手机号码不符合格式'
        });
        return false;
      }
      return true;
    },
    async createdAddress() {
      let result = await this.$http.post('/api/create_address', {
        name: this.name,
        mobile: this.mobile,
        province: this.province,
        city: this.city,
        district: this.district,
        address: this.address
      });
      if (result._http_status !== 200 || result.code !== 0) {
        this.$error({
          text: result.message
        });
        return;
      }
      this.$router.go(-1);
    },
    async changeAddress() {
      let result = await this.$http.post('/api/update_address', {
        address_id: this.id,
        name: this.name,
        mobile: this.mobile,
        province: this.province,
        city: this.city,
        district: this.district,
        address: this.address
      });
      if (result._http_status !== 200 || result.code !== 0) {
        this.$error({
          text: result.message
        });
        return;
      }
      this.$router.go(-1);
    },
    getProvince() {
      return this.$http.post('/api/find_region_ByParentId').then(res => {
        if (res._http_status !== 200 || res.code !== 0) {
          this.$error({
            text: res.message
          });
          return;
        }
        this.provinceList = res.data;
      });
    },
    getCity(id) {
      return this.$http.post('/api/find_region_ByParentId', {
        parentid: id
      }).then(res => {
        if (res._http_status !== 200 || res.code !== 0) {
          this.$error({
            text: res.message
          });
          return;
        }
        this.cityList = res.data;
      });
    },
    getDistrict(id) {
      return this.$http.post('/api/find_region_ByParentId', {
        parentid: id
      }).then(res => {
        if (res._http_status !== 200 || res.code !== 0) {
          this.$error({
            text: res.message
          });
          return;
        }
        this.districtList = res.data;
      });
    }
  }
};
</script>

<style scoped lang="scss">
  .user-change-address {
    padding-bottom: 120px;
    min-height: 100%;
    background-color: #eee;
    .title {
      padding: 30px 40px 20px;
      color: #999;
      font-size: 30px;
    }
    .user-info, .user-address {
      padding-left: 40px;
      background-color: #fff;
      font-size: 34px;
      color: #333;
      .explain {
        label {
          padding: 0 15px;
          width: 200px;
          overflow: hidden;
        }
        span {
          display: inline-block;
          width: 50px;
          text-align: center;
          color: #333333;
          font-size: 24px;
        }
      }
      &>div {
        padding: 25px 40px 25px 0;
        border-top: 1px solid #ccc;
        &:first-child {
          border-top: none;
        }
        input, select {
          width: 100%;
          font-size: 34px;
          height: 44px;
        }
      }
    }
    .warn {
      padding: 40px;
      color: #999;
      font-size: 30px;
    }
    .btn {
      position: fixed;
      left: 50%;
      bottom: 10px;
      transform: translate(-50%, 0);
      width: 95%;
      border-radius: 10px;
      line-height: 100px;
      text-align: center;
      font-size: 44px;
      background-color: #cccccc;
      color: #fff;
      &.allow-submit {
        background-color: #FEA71A;
      }
    }
  }
</style>
