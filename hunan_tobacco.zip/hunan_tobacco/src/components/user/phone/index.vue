<template>
  <div
    class="user-phone"
    flex="dir:top cross:center main:center">
    <div class="iconfont icon-safe"></div>
    <section
      v-if="!submitPhone"
      class="already-submit"
      flex-box="0">
      <p class="mobile">您的手机号：{{ userInfo.phone }}</p>
      <div
        class="btn"
        @click="submitPhone = true">更换手机号</div>
    </section>
    <section
      v-else
      class="no-submit"
      flex-box="0">
      <div
        class="input-phone"
        flex="dir:left cross:center main:justify">
        <p>+86</p>
        <input
          type="tel"
          maxlength="11"
          v-model="mobile"
          placeholder="输入新手机号">
      </div>
      <div
        class="qrCode"
        flex="dir:left cross:center main:justify">
        <input
          type="tel"
          maxlength="4"
          v-model="vcode"
          placeholder="输入验证码">
        <div
          class="btn"
          :class="{disable: countdownTime > 0 || loadingScan}"
          @click="sendVCode">
          <span>点击获取</span>
          <span v-if="countdownTime > 0">{{ countdownTime }}</span>
          <span
            v-if="loadingScan"
            class="iconfont icon-loading"></span>
        </div>
      </div>
      <div
        class="btn"
        @click="checkScanNum">确定</div>
    </section>
  </div>
</template>

<script>
export default {
  name: 'UserPhone',
  components: {},
  data() {
    return {
      submitPhone: false,
      mobile: '',
      vcode: '',
      setTime: null,
      countdownTime: 0,
      loadingScan: false,
      isMobile: false,
      isVCode: false,
    };
  },
  computed: {
    userInfo() {
      return this.$store.state.user;
    }
  },
  watch: {
    countdownTime(val) {
      if (val === 0) clearInterval(this.setTime);
    },
    vcode(val) {
      if (val.length === 4) {
        this.isVCode = true;
      }
    },
    mobile(val) {
      if (val.length === 11) {
        this.checkPhone(val);
      }
    }
  },
  methods: {
    async sendVCode() {
      if (!this.mobile) return;
      if (!this.isMobile) return;
      if (this.countdownTime > 0 || this.loadingScan) return;
      this.loadingScan = true;
      let result = await this.$http.post('/api/send_vcode', {
        mobile: this.mobile
      });
      this.loadingScan = false;
      if (result._http_status !== 200 || result.code !== 0) {
        this.$error({
          text: result.message
        });
        return;
      }
      this.countdownTime = 60;
      this.countdown();
    },
    async checkScanNum() {
      if (!this.mobile) return;
      if (!this.vcode) return;
      let result = await this.$http.post('/api/change_mobile', {
        mobile: this.mobile,
        vcode: this.vcode
      });
      this.$error({
        text: result.message,
        cancel: () => {
          if (result._http_status === 200 && result.code === 0) {
            this.$store.commit('CHANGE_USER_PARAMS', {
              phone: this.mobile
            });
            this.$router.go(-1);
          }
        }
      });
    },
    checkPhone(mobile) {
      let telReg = /^1[3|4|5|6|7|8|9][0-9]\d{8}$/; // 验证手机号
      if (!telReg.test(mobile)) {
        this.$error({
          text: '手机号输入有误！'
        });
      } else {
        this.isMobile = true;
      }
    },
    countdown() {
      this.setTime = setInterval(() => {
        this.countdownTime -= 1;
      }, 1000);
    },
  },
};
</script>

<style scoped lang="scss">
  .user-phone {
    height: 100%;
    background: #eee;
    padding-bottom: 300px;
    .iconfont {
      font-size: 180px;
    }
    .already-submit {
      margin-top: 60px;
      width: 100%;
      text-align: center;
      .mobile {
        font-size: 38px;
        color: #000001;
      }
    }
    .icon-tips {
      margin-right: 15px;
      font-size: 46px;
      color: #FEAB22;
    }
    .no-submit {
      margin-top: 60px;
      width: 100%;
      .input-phone, .qrCode {
        border-bottom: 1px solid #DDDDDD;
        background-color: #fff;
        height: 130px;
        padding: 0 25px;
      }
      .input-phone {
        border-top: 1px solid #DDDDDD;
        font-size: 38px;
        input {
          text-align: right;
          font-size: 38px;
        }
      }
      .qrCode {
        font-size: 32px;
        input {
          font-size: 32px;
        }
        .btn {
          padding: 15px 40px;
          border-radius: 10px;
          background-color: #FEAB22;
          color: #fff;
          &.disable {
            background-color: #666;
          }
          @keyframes turn {
            from {
              transform: rotate(0deg);
            }
            to {
              transform: rotate(360deg);
            }
          }
          .icon-loading {
            display: inline-block;
            animation: turn 2s linear infinite;
            padding-right: 0;
            color: #fff;
            font-size: 24px;
            line-height: 50px;
          }
        }
        .iconfont {
          padding-right: 25px;
          color: #FEAB22;
          font-size: 44px;
        }
      }
    }
    .already-submit, .no-submit {
      &>.btn {
        width: 95%;
        margin: 50px auto 0;
        line-height: 110px;
        text-align: center;
        font-size: 36px;
        border-radius: 6px;
        background-color: #FEAB22;
        color: #fff;
      }
    }
  }
</style>
