import axios from 'axios';
const qs = require('qs');

const getXhrPromise = (config) => {
  return new Promise((resolve) => {
    axios(config).then(res => {
      res.data = res.data || {};
      res.data._http_status = res.status;
      resolve(res.data);
    }).catch(err => {
      let { status } = err.response;
      err.response.data = err.response.data || {};
      err.response.data._http_status = status;
      resolve(err.response.data);
    });
  });
};

export default {
  all(params) {
    return axios.all(params);
  },
  spread(params) {
    return axios.spread(params);
  },
  post(url, data) {
    let config = {
      url,
      method: 'post',
      data: qs.stringify(data),
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    };
    return getXhrPromise(config);
  }
};
