import Vue from 'vue';
import Vuex from 'vuex';
import api from '../assets/axios';

Vue.use(Vuex);

const store = new Vuex.Store({
  state: {
    user: null,
    advert: null,
    advertInit: false,
  },
  mutations: {
    SET_USER(state, params) {
      state.user = params;
    },
    SET_ADVERT(state, params) {
      state.advert = params;
    },
    SET_ADVERT_INIT(state) {
      state.init = true;
    },
    CHANGE_USER_PARAMS(state, params) {
      state.user = Object.assign(state.user, params);
    }
  },
  actions: {
    async init({ commit }) {
      let result = await api.post('/api/user_info');
      let { data } = result;
      commit('SET_USER', data || {});
    }
  }
});

export default store;
