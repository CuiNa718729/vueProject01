import Vue from 'vue';
import Router from 'vue-router';
import wx from 'weixin-js-sdk';
import api from '../assets/axios';
import store from '../vuex';

// Hunan
const hn = () => import('../components/hn');
const home = () => import('../components/hn/home');
const integralMall = () => import('../components/hn/integral-mall');
const personalCenter = () => import('../components/hn/personal-center');
const popularActivity = () => import('../components/hn/popular-activity');
// user
const user = () => import('../components/user');
const userExp = () => import('../components/user/experience');
const userGold = () => import('../components/user/gold');
const userGift = () => import('../components/user/gift');
const userAddress = () => import('../components/user/address');
const userChangeAddress = () => import('../components/user/address/change');
const userTakeGift = () => import('../components/user/gift/take');
const userCard = () => import('../components/user/card');
const userWelfare = () => import('../components/user/welfare');
const userPhone = () => import('../components/user/phone');
const userData = () => import('../components/user/data');

const productDetails = () => import('../components/user/product-details');
const userAdvert = () => import('../components/user/advert');

// mobile
const verificationMobile = () => import('../components/verification-mobile');

Vue.use(Router);

const router = new Router({
  mode: 'history',
  routes: [
    {
      path: '/hunan',
      component: hn,
      children: [
        {
          path: '',
          name: 'home',
          component: home,
          beforeEnter: async (to, from, next) => {
            if (!store.state.user.phone && !to.query.scan) {
              next('/verification-mobile');
              return;
            }
            if (store.state.advertInit) {
              next();
              return;
            }
            let result = await api.post('/api/home_adv');
            store.commit('SET_ADVERT_INIT');
            if (result._http_status === 200 && result.code === 0 && result.data) {
              store.commit('SET_ADVERT', result.data);
              next('/user/advert');
              return;
            }
            next();
          }
        },
        {
          path: 'integral-mall',
          name: 'integralMall',
          meta: {
            title: '积分商城'
          },
          component: integralMall
        },
        {
          path: 'personal-center',
          name: 'personalCenter',
          meta: {
            title: '个人中心'
          },
          component: personalCenter
        },
        {
          path: 'popular-activity',
          name: 'personalActivity',
          meta: {
            title: '热门活动'
          },
          component: popularActivity
        }
      ]
    },
    {
      path: '/user',
      component: user,
      children: [
        {
          path: 'exp',
          name: 'userExp',
          meta: {
            title: '我的经验值'
          },
          component: userExp
        },
        {
          path: 'gold',
          name: 'userGold',
          meta: {
            title: '我的合币'
          },
          component: userGold
        },
        {
          path: 'gift',
          name: 'userGift',
          meta: {
            title: '我的礼品'
          },
          component: userGift
        },
        {
          path: 'address',
          name: 'userAddress',
          meta: {
            title: '地址管理'
          },
          component: userAddress
        },
        {
          path: 'change-address',
          name: 'userChangeAddress',
          meta: {
            title: '编辑地址'
          },
          component: userChangeAddress
        },
        {
          path: 'take-gift',
          name: 'userTakeGift',
          meta: {
            title: '领取奖品'
          },
          component: userTakeGift
        },
        {
          path: 'card',
          name: 'userCard',
          meta: {
            title: '我的卡劵'
          },
          component: userCard
        },
        {
          path: 'welfare',
          name: 'userWelfare',
          meta: {
            title: '我的福利'
          },
          component: userWelfare
        },
        {
          path: 'phone',
          name: 'userPhone',
          meta: {
            title: '修改手机号'
          },
          component: userPhone
        },
        {
          path: 'data',
          name: 'userData',
          meta: {
            title: '个人资料'
          },
          component: userData
        },
        {
          path: 'product-details',
          name: 'productDetails',
          meta: {
            title: '产品详情'
          },
          component: productDetails,
        },
        {
          path: 'advert',
          name: 'userAdvert',
          meta: {
            title: '广告推荐'
          },
          component: userAdvert,
          beforeEnter: (to, from, next) => {
            if (!store.state.advert) {
              next('/hunan');
              return;
            }
            next();
          }
        }
      ]
    },
    {
      path: '/verification-mobile',
      name: 'verificationMobile',
      meta: {
        title: '手机验证'
      },
      component: verificationMobile,
      beforeEnter: (to, from, next) => {
        if (store.state.user.phone) {
          next('/hunan');
          return;
        }
        next();
      }
    },
    {
      path: '/**',
      redirect: '/hunan'
    }
  ]
});

router.beforeEach(async (to, from, next) => {
  if (!store.state.user) await store.dispatch('init');
  next();
});
router.afterEach(async () => {
  let result = await api.post('/api/wechat/tokenjs');
  if (result._http_status !== 200 || result.code !== 0) return;
  let {
    appid,
    timestamp,
    noncestr,
    signature
  } = result.data;
  wx.config({
    debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
    appId: appid, // 必填，公众号的唯一标识
    timestamp: timestamp, // 必填，生成签名的时间戳
    nonceStr: noncestr, // 必填，生成签名的随机串
    signature: signature, // 必填，签名
    jsApiList: ['scanQRCode', 'hideAllNonBaseMenuItem'] // 必填，需要使用的JS接口列表
  });
});

export default router;
