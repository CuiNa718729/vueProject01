import Vue from 'vue';
import App from './App';
import router from './router';
import store from './vuex';
import vueWechatTitle from 'vue-wechat-title';
import error from './components/plugin/error';
import confirm from './components/plugin/confirm';
import axios from './assets/axios';
import { InfiniteScroll } from 'mint-ui';
import './assets/reset.css';
import './assets/font/iconfont.css';
import 'flex.css';

Vue.config.productionTip = false;
Vue.use(InfiniteScroll);
Vue.use(vueWechatTitle);
Vue.use(error);
Vue.use(confirm);
Vue.prototype.$http = axios;

/* eslint-disable no-new */
new Vue({
  el: '#app',
  store,
  router,
  components: { App },
  template: '<App/>'
});
